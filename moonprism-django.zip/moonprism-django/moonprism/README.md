# 🌙 Moon Prism Shop — versão Django

Loja kawaii de Sailor Moon (o seu `sailorstore.html`) agora com backend Django:
login/cadastro, área do cliente, painel administrativo e pagamento real via **Mercado Pago (Pix + cartão)**.
O visual (cores, fontes, animações, carrinho, cards) foi mantido: o CSS original está em `static/css/moonprism.css`
e só foi **acrescentado** (telas novas + responsividade) no final do arquivo.

---

## 1. Rodar no seu computador

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # Windows: copy .env.example .env
python manage.py migrate
python manage.py createcachetable
python manage.py seed_shop         # carrega os 10 produtos e 3 cupons do site original
python manage.py createsuperuser   # seu usuário administrador
python manage.py runserver
```

* Loja: http://localhost:8000
* Painel admin: http://localhost:8000/painel-moon/ (o caminho vem de `DJANGO_ADMIN_URL`)
* Sem `EMAIL_HOST`, os e-mails (confirmação, recuperação de senha) aparecem **no terminal** onde o servidor roda.

Testes automáticos (76 testes): `python manage.py test`

---

## 2. O que você precisa configurar (passo a passo)

### 2.1 Chave secreta do Django
```bash
python -c "import secrets; print(secrets.token_urlsafe(60))"
```
Cole em `DJANGO_SECRET_KEY`. Em produção o site **se recusa a subir** sem ela.

### 2.2 Mercado Pago (pagamento de verdade)
1. Crie conta em <https://www.mercadopago.com.br> e entre em **Seu negócio → Configurações → Credenciais** (ou em *mercadopago.com.br/developers* → **Suas integrações → Criar aplicação**, tipo **Checkout Pro**).
2. **Teste primeiro:** use as **credenciais de teste**. Copie o *Access Token* (`TEST-...`) para `MERCADOPAGO_ACCESS_TOKEN`.
3. Crie **contas de teste** (vendedor e comprador) em *Suas integrações → Contas de teste*. Pague o pedido logado com a conta **compradora de teste**, usando os cartões de teste da documentação do Mercado Pago (procure “cartões de teste”). Nada é cobrado de verdade.
4. **Webhook** (confirmação automática): em *Suas integrações → sua aplicação → Webhooks → Configurar notificações*:
   * URL de produção: `https://SEU-DOMINIO/pagamentos/webhook/`
   * Evento: **Pagamentos**
   * Copie a **Chave secreta** gerada e cole em `MERCADOPAGO_WEBHOOK_SECRET`.
   * Sem essa chave, o servidor **recusa** todo webhook (de propósito, por segurança).
5. **Testar webhook no seu PC:** o Mercado Pago precisa de uma URL pública `https`. Use um túnel (ngrok, cloudflared), coloque o endereço dele em `SITE_URL`, `DJANGO_ALLOWED_HOSTS` e `DJANGO_CSRF_TRUSTED_ORIGINS`. Sem túnel o fluxo ainda funciona: quando o cliente volta ao site, a página de confirmação **consulta o pagamento direto na API do Mercado Pago** e atualiza o pedido.
6. **Produção:** troque pelo *Access Token de produção* (`APP_USR-...`) e ative as credenciais de produção na sua aplicação (o Mercado Pago pede dados da conta).
7. **Parcelas “sem juros”:** o site agora diz “ou até 3× no cartão”. Parcelar sem juros é uma configuração da *sua conta* Mercado Pago (você assume o custo). Se ativar lá, pode voltar o texto “3× sem juros” em `templates/shop/_card.html`.

### 2.3 E-mail (recuperar senha, confirmar e-mail, pedido pago)
Preencha `EMAIL_HOST`, `EMAIL_HOST_USER`, `EMAIL_HOST_PASSWORD`, `DEFAULT_FROM_EMAIL`. Opções gratuitas/baratas: Brevo, Resend, Amazon SES, ou Gmail com “senha de app”. Para entregar bem (não cair no spam), use um e-mail do seu domínio com SPF/DKIM configurados.

### 2.4 Redes sociais e contato
`SOCIAL_INSTAGRAM`, `SOCIAL_PINTEREST`, `SOCIAL_TIKTOK`, `CONTACT_EMAIL`. Vazio = o link não aparece (nada de botão que não leva a lugar nenhum).

---

## 3. Publicar (Render, Railway, Heroku…)

1. Suba o projeto no GitHub (o `.gitignore` já protege `.env` e o banco local).
2. Crie um banco **PostgreSQL** no provedor e copie a URL para `DATABASE_URL`.
3. Variáveis de ambiente no provedor: tudo do `.env.example`, com `DJANGO_DEBUG=False`, `DJANGO_ALLOWED_HOSTS=seudominio`, `DJANGO_CSRF_TRUSTED_ORIGINS=https://seudominio`, `SITE_URL=https://seudominio`, `PROXY_COUNT=1`.
4. **Build:** `pip install -r requirements.txt && python manage.py collectstatic --noinput`
5. **Start:** `gunicorn config.wsgi` (o `Procfile` já tem isso e roda `migrate` + `createcachetable` a cada deploy).
6. No shell do provedor, **uma vez**: `python manage.py seed_shop` e `python manage.py createsuperuser`.
7. HTTPS é forçado em produção (redirect, cookies `Secure`, HSTS). Confira com `python manage.py check --deploy`.

---

## 4. Como o sistema funciona

**Compra:** carrinho (navegador) → `Finalizar compra` → login obrigatório + e-mail confirmado → revisão com **preço, frete e cupom recalculados no servidor** + endereço → cria o **Pedido** (`pendente`) → redireciona ao Checkout do Mercado Pago (Pix/cartão) → volta para a página de confirmação.
Quem muda o status do pedido é **só o gateway**: webhook (assinatura HMAC validada) ou consulta direta à API. O parâmetro `?status=approved` da URL é ignorado.

| Situação no Mercado Pago | Pedido | Pagamento |
|---|---|---|
| aprovado (valor confere) | **Pago** + baixa de estoque + uso do cupom + e-mail | Aprovado |
| pendente / em análise (ex.: Pix aguardando) | Aguardando | Pendente / Em análise |
| recusado / cancelado | **Recusado** (cliente pode tentar de novo) | Recusado / Cancelado |
| reembolsado / chargeback | Reembolsado | Reembolsado |
| aprovado com **valor diferente** do pedido | continua Aguardando (revisão manual) | Aprovado + observação |

**Cartão:** o cliente digita os dados na página do Mercado Pago. Número, CVV e validade **nunca passam pelo seu servidor nem são salvos**; guardamos só ID do pagamento, status, forma, parcelas e valor.

**Perfis de acesso:** cliente (padrão) · equipe (`is_staff`, vê só o que tiver permissão) · superusuário. Crie grupos no painel (ex.: “Atendimento”: ver pedidos e pagamentos) em vez de dar superusuário.

**Painel (`/painel-moon/`):** usuários, produtos (preço, estoque, ativar/desativar), categorias, cupons, pedidos (muda a entrega e o código de rastreio; o status financeiro é somente leitura), pagamentos e notificações do gateway (somente leitura, para auditoria), inscritos da newsletter.

---

## 5. Segurança aplicada

* Senhas com PBKDF2-SHA256 do Django, mínimo de 10 caracteres + validadores de senha comum/numérica/similar.
* Login por e-mail; **bloqueio de 30 min após 5 falhas** (django-axes, por e-mail+IP, ignora maiúsculas).
* Recuperação de senha por link com validade de 2 h, uso único, sem revelar se o e-mail existe.
* Confirmação de e-mail por link assinado (3 dias). Compra exige e-mail confirmado.
* CSRF em todos os formulários e chamadas AJAX; logout só por POST; XSS: templates escapam tudo e o JS escapa dados do carrinho; SQL Injection: só ORM do Django, sem SQL cru.
* Cookies `HttpOnly`, `SameSite=Lax`, `Secure` em produção; HSTS, `X-Frame-Options: DENY`, `nosniff`.
* Pedidos pelo `public_id` (UUID) **e** filtrados pelo dono: pedido de outra conta responde 404.
* Perfil não permite mudar e-mail, permissões nem status de e-mail; só superusuário concede poderes de admin.
* Limite de requisições em cadastro, recuperação de senha, newsletter, cupom, checkout e favoritos.
* Segredos só em variáveis de ambiente; o front nunca recebe chaves (testado).
* Permissões do banco: crie no PostgreSQL um usuário **só com acesso ao banco da loja** (sem superuser/CREATEDB) para o `DATABASE_URL`.

## 6. Estrutura
```
config/      settings, urls
accounts/    usuário (e-mail), cadastro, login, perfil, e-mails
shop/        produtos, categorias, cupons, favoritos, newsletter, cálculo de preço
orders/      pedidos, checkout, histórico
payments/    Mercado Pago, webhook, pagamentos
templates/   base.html + telas        static/   css/js
```
