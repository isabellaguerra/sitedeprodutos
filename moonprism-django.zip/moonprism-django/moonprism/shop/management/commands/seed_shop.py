from decimal import Decimal

from django.core.management.base import BaseCommand

from shop.models import Category, Coupon, Product

CATEGORIES = [
    ("acessorios", "Acessórios", "💍"), ("papelaria", "Papelaria", "📝"), ("peluchas", "Pelúcias", "🐰"),
    ("bolsas", "Bolsas", "👜"), ("novidades", "Novidades", "⭐"),
]

# Catálogo original do site (sailorstore.html)
PRODUCTS = [
    ("Moon Prism Compact", "38.90", "🌙", "Bestseller", "t-bs", "Espelho mágico com glitter prateado e cristal lunar. Cada abertura libera brilhos encantados!", "#FFD6E7", "acessorios"),
    ("Sailor Wand Caneta", "24.50", "⭐", "Novo", "t-no", "Caneta dourada com estrela na ponta. Escreve com tinta que brilha sob luz UV!", "#D6EAFF", "papelaria"),
    ("Crystal Star Colar", "52.00", "💎", "Exclusivo", "t-ex", "Colar prateado com cristal em formato de estrela. Banhado em prata 925.", "#E8D6FF", "acessorios"),
    ("Sailor Moon Plushie", "89.90", "🐰", "Fofo", "t-fo", "Pelúcia 30cm ultra macia com odangos perfeitos. Abraço de lua garantido!", "#FFE8D6", "peluchas"),
    ("Moon Tiara Headband", "31.00", "👑", "Trending", "t-tr", "Tiara dourada com lua crescente em resina cristal. Seja a guerreira que você é!", "#D6FFE8", "acessorios"),
    ("Sailor Lunchbox", "45.00", "🍱", "Novo", "t-no", "Lancheira em formato de transformação. Compartimentos mágicos e fecho com laço!", "#FFD6F5", "novidades"),
    ("Luna Cat Mochila", "120.00", "🐱", "Premium", "t-pr", "Mochila formato Luna com orelhinhas 3D. Bolsos secretos e alças acolchoadas!", "#D6D6FF", "bolsas"),
    ("Sticker Pack Mágico", "12.90", "✨", "Oferta", "t-of", "50 stickers holográficos com personagens e frases icônicas. Brilho infinito!", "#FFF3D6", "papelaria"),
    ("Sailor Venus Pin Set", "19.90", "💛", "Novo", "t-no", "Kit com 6 pinos esmaltados das Sailor Senshi. Detalhes minuciosos e brilhantes!", "#FFFBD6", "acessorios"),
    ("Moon Crystal Garrafa", "35.00", "🔮", "Trending", "t-tr", "Garrafa de água 500ml com cristal lunar decorativo na tampa. Hidrate-se com magia!", "#E8D6FF", "novidades"),
]
COUPONS = [("SAILOR", 10), ("MOON25", 10), ("LUNA", 10)]  # cupons que já existiam no site


class Command(BaseCommand):
    help = "Carrega categorias, produtos e cupons do site original (não duplica se rodar de novo)."

    def handle(self, *args, **opts):
        cats = {}
        for i, (slug, name, emoji) in enumerate(CATEGORIES):
            cats[slug], _ = Category.objects.get_or_create(slug=slug, defaults={"name": name, "emoji": emoji, "position": i})
        created = 0
        for name, price, emoji, tag, tag_class, desc, color, cat in PRODUCTS:
            _, was_new = Product.objects.get_or_create(name=name, defaults={
                "price": Decimal(price), "emoji": emoji, "tag": tag, "tag_class": tag_class,
                "description": desc, "color": color, "category": cats[cat], "is_new": tag == "Novo"})
            created += was_new
        for code, pct in COUPONS:
            Coupon.objects.get_or_create(code=code, defaults={"percent": pct})
        self.stdout.write(self.style.SUCCESS(f"Pronto: {created} produto(s) novo(s), {len(COUPONS)} cupons garantidos."))
