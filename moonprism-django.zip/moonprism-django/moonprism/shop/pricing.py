"""Cálculo de totais no SERVIDOR. O navegador nunca decide preço, frete ou desconto."""
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal

from django.conf import settings

from .models import Coupon, Product

CENT = Decimal("0.01")
MAX_QTY = 20


def money(value):
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)


@dataclass
class Line:
    product: Product
    qty: int

    @property
    def total(self):
        return money(self.product.price * self.qty)


@dataclass
class Quote:
    lines: list = field(default_factory=list)
    coupon: Coupon | None = None
    subtotal: Decimal = Decimal("0.00")
    discount: Decimal = Decimal("0.00")
    shipping: Decimal = Decimal("0.00")
    total: Decimal = Decimal("0.00")
    errors: list = field(default_factory=list)


def get_coupon(code):
    code = (code or "").strip().upper()
    if not code:
        return None
    coupon = Coupon.objects.filter(code=code).first()
    return coupon if coupon and coupon.is_usable else None


def build_quote(items, coupon_code=""):
    """`items`: lista de {"id": int, "qty": int} vinda do navegador (não confiável)."""
    quote = Quote()
    merged = {}
    for raw in items or []:
        try:
            pid, qty = int(raw["id"]), int(raw["qty"])
        except (KeyError, TypeError, ValueError):
            quote.errors.append("Item inválido no carrinho.")
            continue
        if qty < 1:
            continue
        merged[pid] = min(merged.get(pid, 0) + qty, MAX_QTY)

    products = {p.id: p for p in Product.objects.filter(id__in=merged.keys(), is_active=True)}
    for pid, qty in merged.items():
        product = products.get(pid)
        if not product:
            quote.errors.append("Um dos itens não está mais disponível e foi removido.")
            continue
        if product.stock < qty:
            quote.errors.append(f"“{product.name}”: só temos {product.stock} em estoque.")
            qty = product.stock
            if qty < 1:
                continue
        quote.lines.append(Line(product, qty))

    quote.subtotal = money(sum((l.total for l in quote.lines), Decimal("0")))
    coupon = get_coupon(coupon_code)
    if coupon_code and not coupon:
        quote.errors.append("Cupom inválido ou expirado.")
    if coupon and quote.lines:
        quote.coupon = coupon
        quote.discount = money(quote.subtotal * coupon.percent / 100)
    free_from = Decimal(settings.FREE_SHIPPING_FROM)
    quote.shipping = Decimal("0.00") if (not quote.lines or quote.subtotal >= free_from) else money(settings.SHIPPING_FLAT)
    quote.total = money(quote.subtotal - quote.discount + quote.shipping)
    return quote
