from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone
from django.utils.text import slugify


class Category(models.Model):
    slug = models.SlugField("identificador", unique=True)
    name = models.CharField("nome", max_length=60)
    emoji = models.CharField("emoji", max_length=8, blank=True)
    position = models.PositiveSmallIntegerField("ordem", default=0)

    class Meta:
        verbose_name = "categoria"
        ordering = ["position", "name"]

    def __str__(self):
        return f"{self.emoji} {self.name}".strip()


class Product(models.Model):
    TAGS = [
        ("t-bs", "Bestseller"), ("t-no", "Novo"), ("t-ex", "Exclusivo"), ("t-fo", "Fofo"),
        ("t-tr", "Trending"), ("t-pr", "Premium"), ("t-of", "Oferta"),
    ]
    name = models.CharField("nome", max_length=120)
    slug = models.SlugField(unique=True, blank=True)
    description = models.TextField("descrição", max_length=400)
    price = models.DecimalField("preço (R$)", max_digits=8, decimal_places=2,
                                validators=[MinValueValidator(Decimal("0.01"))])
    emoji = models.CharField("emoji", max_length=8, default="✨")
    color = models.CharField("cor do card", max_length=7, default="#FFD6E7",
                             help_text="Hexadecimal, ex.: #FFD6E7")
    tag = models.CharField("selo", max_length=20, blank=True)
    tag_class = models.CharField("estilo do selo", max_length=6, choices=TAGS, default="t-no")
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products", verbose_name="categoria")
    is_new = models.BooleanField("aparece em Novidades", default=False)
    stock = models.PositiveIntegerField("estoque", default=50)
    is_active = models.BooleanField("à venda", default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "produto"
        ordering = ["id"]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.name) or "produto"
            slug, i = base, 2
            while Product.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug, i = f"{base}-{i}", i + 1
            self.slug = slug
        super().save(*args, **kwargs)


class Coupon(models.Model):
    code = models.CharField("código", max_length=30, unique=True)
    percent = models.PositiveSmallIntegerField("desconto (%)", validators=[MinValueValidator(1)])
    is_active = models.BooleanField("ativo", default=True)
    valid_until = models.DateTimeField("válido até", null=True, blank=True)
    max_uses = models.PositiveIntegerField("limite de usos", null=True, blank=True)
    times_used = models.PositiveIntegerField("usos", default=0, editable=False)

    class Meta:
        verbose_name = "cupom"
        verbose_name_plural = "cupons"

    def __str__(self):
        return f"{self.code} ({self.percent}%)"

    def save(self, *args, **kwargs):
        self.code = self.code.strip().upper()
        super().save(*args, **kwargs)

    @property
    def is_usable(self):
        if not self.is_active:
            return False
        if self.valid_until and self.valid_until < timezone.now():
            return False
        if self.max_uses is not None and self.times_used >= self.max_uses:
            return False
        return self.percent <= 90


class Wishlist(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="wishlist")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="wished_by")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "favorito"
        constraints = [models.UniqueConstraint(fields=["user", "product"], name="uniq_wish")]


class NewsletterSubscriber(models.Model):
    email = models.EmailField("e-mail", unique=True)
    created_at = models.DateTimeField("inscrito em", auto_now_add=True)
    is_active = models.BooleanField("ativo", default=True)

    class Meta:
        verbose_name = "inscrito na newsletter"
        verbose_name_plural = "inscritos na newsletter"
        ordering = ["-created_at"]

    def __str__(self):
        return self.email
