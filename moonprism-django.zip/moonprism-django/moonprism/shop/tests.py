import json

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .models import NewsletterSubscriber, Wishlist
from .testing import make_catalog, make_coupon, make_order, make_user


class StorefrontTests(TestCase):
    def setUp(self):
        cache.clear()
        self.a, self.b, self.off = make_catalog()

    def test_home_lists_only_active_products_with_original_layout(self):
        r = self.client.get(reverse("shop:home"))
        self.assertContains(r, "Moon Prism Compact")
        self.assertContains(r, "Em nome da Lua,")
        self.assertContains(r, "Nossa Coleção Mágica")
        self.assertNotContains(r, "Fora de linha")
        self.assertContains(r, "R$ 38,90")

    def test_every_page_renders(self):
        user = make_user("ana@example.com")
        urls = [reverse("shop:home"), reverse("accounts:login"), reverse("accounts:signup"), reverse("accounts:password_reset"),
                reverse("accounts:password_reset_done"), reverse("accounts:password_reset_complete")]
        urls += [reverse("shop:page", args=[s]) for s in ("como-comprar", "trocas", "contato", "nossa-historia")]
        for u in urls:
            self.assertEqual(self.client.get(u).status_code, 200, u)
        self.client.force_login(user)
        o = make_order(user, self.a)
        for u in [reverse(n) for n in ("accounts:dashboard", "accounts:profile", "accounts:password_change", "orders:list", "shop:wishlist")] + \
                 [reverse("orders:detail", args=[o.public_id]), reverse("orders:confirmation", args=[o.public_id])]:
            self.assertEqual(self.client.get(u).status_code, 200, u)

    def test_unknown_page_is_404_with_friendly_template(self):
        self.assertContains(self.client.get("/ajuda/inexistente/"), "Página não encontrada", status_code=404)

    def test_no_secrets_exposed_in_html(self):
        with self.settings(MERCADOPAGO_ACCESS_TOKEN="APP_USR-super-secreto", MERCADOPAGO_WEBHOOK_SECRET="whsec", SECRET_KEY="chave-django-xyz"):
            html = self.client.get(reverse("shop:home")).content.decode()
        for secret in ("APP_USR-super-secreto", "whsec", "chave-django-xyz"):
            self.assertNotIn(secret, html)

    def test_html_escapes_product_text(self):
        self.a.name = "<script>alert(1)</script>"; self.a.save()
        html = self.client.get(reverse("shop:home")).content.decode()
        self.assertNotIn("<script>alert(1)</script>", html)

    def test_coupon_endpoint(self):
        make_coupon("MOON25", 10)
        post = lambda code: self.client.post(reverse("shop:coupon"), json.dumps({"code": code}), content_type="application/json").json()
        self.assertEqual(post("moon25"), {"ok": True, "code": "MOON25", "percent": 10})
        self.assertFalse(post("NADA")["ok"])
        self.assertEqual(self.client.get(reverse("shop:coupon")).status_code, 405)

    def test_newsletter_saves_and_validates(self):
        ok = self.client.post(reverse("shop:newsletter"), {"email": "Fa@Example.com"}).json()
        self.assertTrue(ok["ok"])
        self.client.post(reverse("shop:newsletter"), {"email": "fa@example.com"})
        self.assertEqual(NewsletterSubscriber.objects.count(), 1)
        self.assertFalse(self.client.post(reverse("shop:newsletter"), {"email": "x"}).json()["ok"])

    def test_newsletter_is_rate_limited(self):
        for i in range(5):
            self.client.post(reverse("shop:newsletter"), {"email": f"a{i}@example.com"})
        self.assertEqual(self.client.post(reverse("shop:newsletter"), {"email": "z@example.com"}).status_code, 429)

    def test_wishlist_requires_login_and_toggles_per_user(self):
        url = reverse("shop:toggle_wish", args=[self.a.id])
        self.assertEqual(self.client.post(url).status_code, 401)
        ana, bia = make_user("ana@example.com"), make_user("bia@example.com")
        self.client.force_login(ana)
        self.assertTrue(self.client.post(url).json()["wished"])
        self.assertContains(self.client.get(reverse("shop:wishlist")), "Moon Prism Compact")
        self.client.force_login(bia)
        self.assertNotContains(self.client.get(reverse("shop:wishlist")), "Moon Prism Compact")
        self.client.force_login(ana)
        self.assertFalse(self.client.post(url).json()["wished"])
        self.assertEqual(Wishlist.objects.count(), 0)
        self.assertEqual(self.client.post(reverse("shop:toggle_wish", args=[self.off.id])).status_code, 404)

    def test_csrf_enforced_on_state_changing_posts(self):
        from django.test import Client
        c = Client(enforce_csrf_checks=True)
        c.force_login(make_user("ana@example.com"))
        for url in (reverse("shop:newsletter"), reverse("orders:checkout"), reverse("accounts:logout"), reverse("shop:toggle_wish", args=[self.a.id])):
            self.assertEqual(c.post(url, {}).status_code, 403, url)


class AdminAccessTests(TestCase):
    def setUp(self):
        cache.clear()
        self.admin_url = "/painel-moon/"
        self.a, _, _ = make_catalog()
        self.customer = make_user("cli@example.com")
        self.root = get_user_model().objects.create_superuser("root@example.com", "Senha-Super-Forte-1", full_name="Root")
        self.order = make_order(self.customer, self.a)

    def test_default_admin_url_not_exposed(self):
        self.assertEqual(self.client.get("/admin/").status_code, 404)

    def test_anonymous_and_customers_cannot_use_admin(self):
        r = self.client.get(self.admin_url)
        self.assertEqual(r.status_code, 302); self.assertIn("login", r["Location"])
        self.client.force_login(self.customer)
        r = self.client.get(self.admin_url)
        self.assertEqual(r.status_code, 302); self.assertIn("login", r["Location"])
        r = self.client.get(self.admin_url + "orders/order/")
        self.assertEqual(r.status_code, 302)

    def test_staff_without_permissions_sees_nothing(self):
        staff = make_user("staff@example.com", is_staff=True)
        self.client.force_login(staff)
        self.assertEqual(self.client.get(self.admin_url).status_code, 200)
        self.assertEqual(self.client.get(self.admin_url + "orders/order/").status_code, 403)
        self.assertEqual(self.client.get(self.admin_url + "accounts/user/").status_code, 403)

    def test_staff_with_view_permission_only_cannot_change_orders(self):
        staff = make_user("staff@example.com", is_staff=True)
        staff.user_permissions.add(Permission.objects.get(codename="view_order"))
        self.client.force_login(staff)
        self.assertEqual(self.client.get(self.admin_url + "orders/order/").status_code, 200)
        r = self.client.post(self.admin_url + f"orders/order/{self.order.pk}/change/", {"fulfillment": "shipped"})
        self.assertEqual(r.status_code, 403)

    def test_staff_cannot_grant_superuser(self):
        staff = make_user("staff@example.com", is_staff=True)
        for c in ("view_user", "change_user"):
            staff.user_permissions.add(Permission.objects.get(codename=c))
        self.client.force_login(staff)
        data = {"email": staff.email, "full_name": "S", "is_superuser": "on", "is_staff": "on", "is_active": "on",
                "date_joined_0": "2026-01-01", "date_joined_1": "10:00:00"}
        self.client.post(self.admin_url + f"accounts/user/{staff.pk}/change/", data)
        staff.refresh_from_db()
        self.assertFalse(staff.is_superuser)

    def test_superuser_sees_everything_and_payments_are_read_only(self):
        self.client.force_login(self.root)
        for path in ("", "accounts/user/", "orders/order/", "payments/payment/", "payments/webhookevent/", "shop/product/",
                     "shop/coupon/", "shop/category/", "shop/newslettersubscriber/", f"orders/order/{self.order.pk}/change/"):
            self.assertEqual(self.client.get(self.admin_url + path).status_code, 200, path)
        self.assertEqual(self.client.get(self.admin_url + "payments/payment/add/").status_code, 403)
        self.assertEqual(self.client.get(self.admin_url + "orders/order/add/").status_code, 403)
        self.assertEqual(self.client.get(self.admin_url + "accounts/user/add/").status_code, 200)

    def test_admin_can_update_fulfillment_only_on_paid_orders(self):
        self.client.force_login(self.root)
        self.client.post(self.admin_url + "orders/order/", {"action": "mark_shipped", "_selected_action": [self.order.pk]})
        self.order.refresh_from_db()
        self.assertEqual(self.order.fulfillment, "new")  # pendente: não envia
        self.order.status = "paid"; self.order.save()
        self.client.post(self.admin_url + "orders/order/", {"action": "mark_shipped", "_selected_action": [self.order.pk]})
        self.order.refresh_from_db()
        self.assertEqual(self.order.fulfillment, "shipped")
