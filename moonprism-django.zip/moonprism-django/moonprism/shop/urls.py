from django.urls import path

from . import views

app_name = "shop"

urlpatterns = [
    path("", views.home, name="home"),
    path("cupom/", views.check_coupon, name="coupon"),
    path("favoritos/", views.wishlist, name="wishlist"),
    path("favoritos/<int:product_id>/", views.toggle_wish, name="toggle_wish"),
    path("newsletter/", views.newsletter, name="newsletter"),
    path("ajuda/<slug:slug>/", views.page, name="page"),
]
