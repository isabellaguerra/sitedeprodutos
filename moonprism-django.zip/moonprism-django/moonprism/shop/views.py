import json

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import Category, NewsletterSubscriber, Product, Wishlist
from .pricing import get_coupon
from .throttle import throttle

def _product_payload(products):
    return [{
        "id": p.id, "name": p.name, "emoji": p.emoji, "price": str(p.price), "stock": p.stock,
    } for p in products]


def _wished_ids(request):
    if request.user.is_authenticated:
        return set(Wishlist.objects.filter(user=request.user).values_list("product_id", flat=True))
    return set()


def home(request):
    products = list(Product.objects.filter(is_active=True).select_related("category"))
    return render(request, "shop/home.html", {
        "products": products,
        "categories": Category.objects.all(),
        "wished": _wished_ids(request),
        "products_json": _product_payload(products),
        "cfg_json": {"freeFrom": settings.FREE_SHIPPING_FROM, "flat": settings.SHIPPING_FLAT,
                     "auth": request.user.is_authenticated},
        "initial_cat": request.GET.get("cat", "all"),
        "initial_q": request.GET.get("q", "")[:60],
    })


@require_POST
@throttle("coupon", limit=20, window=600, json=True)
def check_coupon(request):
    try:
        code = json.loads(request.body or "{}").get("code", "")
    except ValueError:
        code = ""
    coupon = get_coupon(code)
    if not coupon:
        return JsonResponse({"ok": False, "error": "Código inválido ou expirado."})
    return JsonResponse({"ok": True, "code": coupon.code, "percent": coupon.percent})


@require_POST
@throttle("wish", limit=60, window=600, json=True)
def toggle_wish(request, product_id):
    if not request.user.is_authenticated:
        return JsonResponse({"ok": False, "login": True}, status=401)
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    obj, created = Wishlist.objects.get_or_create(user=request.user, product=product)
    if not created:
        obj.delete()
    return JsonResponse({"ok": True, "wished": created})


@login_required
def wishlist(request):
    products = Product.objects.filter(wished_by__user=request.user, is_active=True)
    return render(request, "shop/wishlist.html", {
        "products": products, "wished": {p.id for p in products}, "products_json": _product_payload(products),
        "cfg_json": {"freeFrom": settings.FREE_SHIPPING_FROM, "flat": settings.SHIPPING_FLAT, "auth": True},
    })


@require_POST
@throttle("newsletter", limit=5, window=3600, json=True)
def newsletter(request):
    email = (request.POST.get("email") or "").strip().lower()[:254]
    try:
        validate_email(email)
    except ValidationError:
        return JsonResponse({"ok": False, "error": "Esse e-mail não parece válido."})
    NewsletterSubscriber.objects.get_or_create(email=email)
    return JsonResponse({"ok": True})


PAGES = {
    "como-comprar": ("Como comprar", "shop/pages/como_comprar.html"),
    "trocas": ("Trocas e devoluções", "shop/pages/trocas.html"),
    "contato": ("Contato", "shop/pages/contato.html"),
    "nossa-historia": ("Nossa história", "shop/pages/historia.html"),
}


def page(request, slug):
    if slug not in PAGES:
        return error_404(request, None)
    title, template = PAGES[slug]
    return render(request, template, {"page_title": title})


def error_404(request, exception):
    return render(request, "errors/404.html", status=404)


def error_403(request, exception):
    return render(request, "errors/403.html", status=403)


def error_500(request):
    return render(request, "errors/500.html", status=500)
