from django.contrib import admin

from .models import Category, Coupon, NewsletterSubscriber, Product

admin.site.site_header = "Moon Prism Shop — painel"
admin.site.site_title = "Moon Prism Shop"
admin.site.index_title = "Gerenciar a loja 🌙"


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("emoji", "name", "slug", "position")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("emoji", "name", "category", "price", "stock", "is_new", "is_active")
    list_filter = ("category", "is_active", "is_new")
    list_editable = ("price", "stock", "is_active")
    search_fields = ("name", "description")
    list_display_links = ("name",)


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ("code", "percent", "is_active", "valid_until", "times_used", "max_uses")
    list_filter = ("is_active",)


@admin.register(NewsletterSubscriber)
class NewsletterAdmin(admin.ModelAdmin):
    list_display = ("email", "created_at", "is_active")
    list_filter = ("is_active",)
    search_fields = ("email",)
    readonly_fields = ("created_at",)
