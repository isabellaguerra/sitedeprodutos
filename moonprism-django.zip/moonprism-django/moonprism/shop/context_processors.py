from django.conf import settings

from .models import Category


def site(request):
    return {
        "SOCIAL_INSTAGRAM": settings.SOCIAL_INSTAGRAM,
        "SOCIAL_PINTEREST": settings.SOCIAL_PINTEREST,
        "SOCIAL_TIKTOK": settings.SOCIAL_TIKTOK,
        "CONTACT_EMAIL": settings.CONTACT_EMAIL,
        "FREE_SHIPPING_FROM": settings.FREE_SHIPPING_FROM,
        "SHIPPING_FLAT": settings.SHIPPING_FLAT,
        "nav_categories": Category.objects.all(),
    }
