"""Fábricas usadas nos testes."""
from decimal import Decimal

from django.contrib.auth import get_user_model

from orders.models import Order, OrderItem

from .models import Category, Coupon, Product

PASSWORD = "Lua-de-Cristal-2026!"


def make_user(email="ana@example.com", verified=True, **extra):
    User = get_user_model()
    user = User.objects.create_user(email=email, password=PASSWORD, full_name=extra.pop("full_name", "Ana Souza"),
                                    email_verified=verified, **extra)
    return user


def make_address(user):
    user.cep, user.street, user.number, user.district, user.city, user.state = (
        "11700000", "Rua das Estrelas", "42", "Boqueirão", "Praia Grande", "SP")
    user.phone = "13999998888"
    user.save()
    return user


def make_catalog():
    cat, _ = Category.objects.get_or_create(slug="acessorios", defaults={"name": "Acessórios", "emoji": "💍"})
    a = Product.objects.create(name="Moon Prism Compact", price=Decimal("38.90"), category=cat, description="x", stock=5, emoji="🌙")
    b = Product.objects.create(name="Luna Cat Mochila", price=Decimal("120.00"), category=cat, description="y", stock=3, emoji="🐱")
    off = Product.objects.create(name="Fora de linha", price=Decimal("10.00"), category=cat, description="z", is_active=False)
    return a, b, off


def make_order(user, product, qty=1, status=Order.Status.PENDING, coupon=""):
    total = product.price * qty
    order = Order.objects.create(user=user, status=status, subtotal=total, total=total, coupon_code=coupon,
                                 ship_name=user.full_name, ship_address="Rua X, 1")
    OrderItem.objects.create(order=order, product=product, name=product.name, emoji=product.emoji,
                             unit_price=product.price, quantity=qty)
    return order


def make_coupon(code="SAILOR", percent=10, **kw):
    return Coupon.objects.create(code=code, percent=percent, **kw)
