"""Limite simples de requisições por IP (formulários públicos: cadastro, recuperação de senha, newsletter...)."""
import functools

from django.conf import settings
from django.contrib import messages
from django.core.cache import cache
from django.http import HttpResponse
from django.shortcuts import redirect


def client_ip(request):
    meta = request.META
    count = getattr(settings, "PROXY_COUNT", 0)
    if count:
        parts = [p.strip() for p in meta.get("HTTP_X_FORWARDED_FOR", "").split(",") if p.strip()]
        if len(parts) >= count:
            return parts[-count]
    return meta.get("REMOTE_ADDR", "0.0.0.0")


def throttle(key, limit=5, window=600, json=False):
    """Permite `limit` POSTs a cada `window` segundos por IP."""

    def decorator(view):
        @functools.wraps(view)
        def wrapped(request, *args, **kwargs):
            if request.method == "POST":
                cache_key = f"thr:{key}:{client_ip(request)}"
                try:
                    cache.add(cache_key, 0, window)
                    hits = cache.incr(cache_key)
                except ValueError:
                    cache.set(cache_key, 1, window)
                    hits = 1
                if hits > limit:
                    if json:
                        return HttpResponse('{"ok": false, "error": "Muitas tentativas. Aguarde um pouco."}',
                                            status=429, content_type="application/json")
                    messages.error(request, "Muitas tentativas seguidas. Aguarde alguns minutos e tente de novo.")
                    return redirect(request.META.get("HTTP_REFERER") or "shop:home")
            return view(request, *args, **kwargs)

        return wrapped

    return decorator
