import uuid

from django.conf import settings
from django.db import models

from shop.models import Product


class Order(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Aguardando pagamento"
        PAID = "paid", "Pago"
        FAILED = "failed", "Pagamento recusado"
        CANCELLED = "cancelled", "Cancelado"
        REFUNDED = "refunded", "Reembolsado"

    class Fulfillment(models.TextChoices):
        NEW = "new", "Aguardando envio"
        PREPARING = "preparing", "Em separação"
        SHIPPED = "shipped", "Enviado"
        DELIVERED = "delivered", "Entregue"

    # O público usa public_id (UUID) nas URLs e no gateway: não dá para "adivinhar" pedidos alheios.
    public_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="orders",
                             verbose_name="cliente")
    status = models.CharField("status do pagamento", max_length=10, choices=Status.choices,
                              default=Status.PENDING, db_index=True)
    fulfillment = models.CharField("status da entrega", max_length=10, choices=Fulfillment.choices,
                                   default=Fulfillment.NEW)
    tracking_code = models.CharField("código de rastreio", max_length=40, blank=True)

    subtotal = models.DecimalField(max_digits=9, decimal_places=2)
    discount = models.DecimalField("desconto", max_digits=9, decimal_places=2, default=0)
    shipping = models.DecimalField("frete", max_digits=9, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=9, decimal_places=2)
    coupon_code = models.CharField("cupom", max_length=30, blank=True)

    # Endereço no momento da compra (não muda se o cliente editar o perfil depois)
    ship_name = models.CharField("destinatário", max_length=150)
    ship_phone = models.CharField("telefone", max_length=15, blank=True)
    ship_address = models.CharField("endereço de entrega", max_length=300)

    created_at = models.DateTimeField("criado em", auto_now_add=True)
    paid_at = models.DateTimeField("pago em", null=True, blank=True)
    stock_applied = models.BooleanField(default=False, editable=False)

    class Meta:
        verbose_name = "pedido"
        ordering = ["-created_at"]

    def __str__(self):
        return f"Pedido {self.code}"

    @property
    def code(self):
        return "MP-" + str(self.public_id).split("-")[0].upper()

    @property
    def can_pay(self):
        return self.status in (self.Status.PENDING, self.Status.FAILED)


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, blank=True)
    name = models.CharField("produto", max_length=120)
    emoji = models.CharField(max_length=8, blank=True)
    unit_price = models.DecimalField("preço unitário", max_digits=8, decimal_places=2)
    quantity = models.PositiveSmallIntegerField("qtd.")

    class Meta:
        verbose_name = "item do pedido"

    @property
    def total(self):
        return self.unit_price * self.quantity

    def __str__(self):
        return f"{self.quantity}× {self.name}"
