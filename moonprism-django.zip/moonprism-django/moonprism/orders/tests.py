import json
from decimal import Decimal
from unittest.mock import MagicMock, patch

from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from shop.pricing import build_quote
from shop.testing import make_address, make_catalog, make_coupon, make_order, make_user

from .models import Order

MP = {"MERCADOPAGO_ACCESS_TOKEN": "TEST-token", "SITE_URL": "https://loja.test"}


def fake_sdk(init_point="https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=1", status=201):
    sdk = MagicMock()
    sdk.preference.return_value.create.return_value = {"status": status, "response": {"init_point": init_point} if status == 201 else {"message": "x"}}
    return sdk


class PricingTests(TestCase):
    def setUp(self):
        self.a, self.b, self.off = make_catalog()

    def test_server_ignores_client_prices_and_applies_shipping_rule(self):
        q = build_quote([{"id": self.a.id, "qty": 2, "price": "0.01"}])
        self.assertEqual(q.subtotal, Decimal("77.80"))
        self.assertEqual(q.shipping, Decimal("15.90"))
        self.assertEqual(q.total, Decimal("93.70"))

    def test_free_shipping_from_199(self):
        q = build_quote([{"id": self.b.id, "qty": 2}])  # 240
        self.assertEqual(q.shipping, Decimal("0.00"))

    def test_coupon_discount_and_invalid_coupon(self):
        make_coupon("SAILOR", 10)
        q = build_quote([{"id": self.b.id, "qty": 1}], "sailor")
        self.assertEqual(q.discount, Decimal("12.00"))
        self.assertEqual(q.total, Decimal("120.00") - Decimal("12.00") + Decimal("15.90"))
        q = build_quote([{"id": self.b.id, "qty": 1}], "FALSO")
        self.assertTrue(q.errors); self.assertEqual(q.discount, 0)

    def test_inactive_unknown_negative_and_garbage_items(self):
        q = build_quote([{"id": self.off.id, "qty": 1}, {"id": 99999, "qty": 1}, {"id": self.a.id, "qty": -5}, {"id": "x", "qty": 1}, {"qty": 1}])
        self.assertEqual(q.lines, []); self.assertEqual(q.subtotal, 0)

    def test_quantity_capped_by_stock(self):
        q = build_quote([{"id": self.b.id, "qty": 10}])  # estoque 3
        self.assertEqual(q.lines[0].qty, 3); self.assertTrue(q.errors)


@override_settings(**MP)
class CheckoutTests(TestCase):
    def setUp(self):
        cache.clear()
        self.a, self.b, _ = make_catalog()
        self.user = make_user("ana@example.com")
        self.cart = json.dumps([{"id": self.a.id, "qty": 2}])
        self.addr = {"full_name": "Ana Souza", "phone": "(13) 99999-8888", "cep": "11700-000", "street": "Rua A",
                     "number": "10", "complement": "", "district": "Centro", "city": "Praia Grande", "state": "SP"}

    def test_checkout_requires_login_and_post(self):
        r = self.client.post(reverse("orders:checkout"), {"cart": self.cart})
        self.assertEqual(r.status_code, 302); self.assertIn("/conta/entrar/", r["Location"])
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse("orders:checkout")).status_code, 405)

    def test_unverified_email_cannot_checkout(self):
        u = make_user("nv@example.com", verified=False)
        self.client.force_login(u)
        r = self.client.post(reverse("orders:checkout"), {"cart": self.cart})
        self.assertRedirects(r, reverse("accounts:dashboard"), fetch_redirect_response=False)
        self.assertEqual(Order.objects.count(), 0)

    def test_review_step_shows_server_totals(self):
        self.client.force_login(self.user)
        r = self.client.post(reverse("orders:checkout"), {"cart": self.cart, "action": "review"})
        self.assertContains(r, "93,70")
        self.assertEqual(Order.objects.count(), 0)

    def test_empty_cart_redirects(self):
        self.client.force_login(self.user)
        r = self.client.post(reverse("orders:checkout"), {"cart": "[]"})
        self.assertRedirects(r, reverse("shop:home"), fetch_redirect_response=False)

    def test_pay_creates_order_and_sends_exact_total_to_gateway(self):
        make_coupon("SAILOR", 10)
        self.client.force_login(self.user)
        sdk = fake_sdk()
        with patch("payments.services.mercadopago.SDK", return_value=sdk) as ctor:
            r = self.client.post(reverse("orders:checkout"), {"cart": self.cart, "coupon": "SAILOR", "action": "pay", **self.addr})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r["Location"].startswith("https://www.mercadopago.com.br/"))
        ctor.assert_called_once_with("TEST-token")
        order = Order.objects.get()
        # 77,80 - 10% (7,78) + frete 15,90
        self.assertEqual((order.subtotal, order.discount, order.shipping, order.total),
                         (Decimal("77.80"), Decimal("7.78"), Decimal("15.90"), Decimal("85.92")))
        self.assertEqual(order.status, Order.Status.PENDING)
        self.assertEqual(order.items.get().unit_price, Decimal("38.90"))
        sent = sdk.preference.return_value.create.call_args[0][0]
        self.assertEqual(sent["items"][0]["unit_price"], 85.92)
        self.assertEqual(sent["external_reference"], str(order.public_id))
        self.assertTrue(sent["notification_url"].startswith("https://loja.test/pagamentos/webhook/"))
        self.assertEqual({t["id"] for t in sent["payment_methods"]["excluded_payment_types"]}, {"ticket", "atm"})
        self.assertNotIn("card", json.dumps(sent).lower().replace("credit_card", ""))
        self.user.refresh_from_db()
        self.assertEqual(self.user.cep, "11700000")  # endereço salvo no perfil

    def test_pay_with_invalid_address_creates_nothing(self):
        self.client.force_login(self.user)
        r = self.client.post(reverse("orders:checkout"), {"cart": self.cart, "action": "pay", **dict(self.addr, cep="1", street="")})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Order.objects.count(), 0)

    def test_gateway_failure_keeps_order_pending_and_shows_message(self):
        self.client.force_login(self.user)
        with patch("payments.services.mercadopago.SDK", return_value=fake_sdk(status=400)):
            r = self.client.post(reverse("orders:checkout"), {"cart": self.cart, "action": "pay", **self.addr}, follow=True)
        self.assertContains(r, "Mercado Pago não aceitou")
        self.assertEqual(Order.objects.get().status, Order.Status.PENDING)

    @override_settings(MERCADOPAGO_ACCESS_TOKEN="")
    def test_missing_gateway_credentials_is_friendly(self):
        self.client.force_login(self.user)
        r = self.client.post(reverse("orders:checkout"), {"cart": self.cart, "action": "pay", **self.addr}, follow=True)
        self.assertContains(r, "ainda não foi configurado")

    def test_tampered_price_in_cart_is_ignored(self):
        self.client.force_login(self.user)
        cart = json.dumps([{"id": self.a.id, "qty": 1, "price": 0.01, "unit_price": 0.01}])
        with patch("payments.services.mercadopago.SDK", return_value=fake_sdk()):
            self.client.post(reverse("orders:checkout"), {"cart": cart, "action": "pay", **self.addr})
        self.assertEqual(Order.objects.get().subtotal, Decimal("38.90"))


@override_settings(**MP)
class OrderAccessTests(TestCase):
    def setUp(self):
        cache.clear()
        self.a, _, _ = make_catalog()
        self.ana, self.bia = make_user("ana@example.com"), make_user("bia@example.com", full_name="Bia Lima")
        self.order = make_order(self.ana, self.a)

    def test_owner_can_view(self):
        self.client.force_login(self.ana)
        for name in ("orders:detail", "orders:confirmation"):
            self.assertEqual(self.client.get(reverse(name, args=[self.order.public_id])).status_code, 200)

    def test_other_user_gets_404_everywhere(self):
        self.client.force_login(self.bia)
        for name in ("orders:detail", "orders:confirmation"):
            self.assertEqual(self.client.get(reverse(name, args=[self.order.public_id])).status_code, 404)
        self.assertEqual(self.client.post(reverse("orders:repay", args=[self.order.public_id])).status_code, 404)

    def test_anonymous_redirected(self):
        r = self.client.get(reverse("orders:detail", args=[self.order.public_id]))
        self.assertEqual(r.status_code, 302)

    def test_list_only_shows_own_orders(self):
        make_order(self.bia, self.a, qty=3)
        self.client.force_login(self.ana)
        r = self.client.get(reverse("orders:list"))
        self.assertContains(r, self.order.code)
        self.assertEqual(len(r.context["orders"]), 1)

    def test_cannot_repay_paid_order(self):
        self.order.status = Order.Status.PAID; self.order.save()
        self.client.force_login(self.ana)
        self.assertEqual(self.client.post(reverse("orders:repay", args=[self.order.public_id])).status_code, 404)

    def test_repay_failed_order_redirects_to_gateway(self):
        self.order.status = Order.Status.FAILED; self.order.save()
        self.client.force_login(self.ana)
        with patch("payments.services.mercadopago.SDK", return_value=fake_sdk()):
            r = self.client.post(reverse("orders:repay", args=[self.order.public_id]))
        self.assertEqual(r.status_code, 302); self.assertIn("mercadopago", r["Location"])
