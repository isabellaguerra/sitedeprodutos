from accounts.forms import ProfileForm


class CheckoutAddressForm(ProfileForm):
    """Endereço de entrega no checkout: mesmas validações do perfil, mas tudo obrigatório."""

    class Meta(ProfileForm.Meta):
        fields = ["full_name", "phone", "cep", "street", "number", "complement", "district", "city", "state"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name in ("full_name", "phone", "cep", "street", "number", "district", "city", "state"):
            self.fields[name].required = True
