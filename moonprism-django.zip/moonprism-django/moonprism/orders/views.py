import json

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from payments import services as pay
from shop.pricing import build_quote
from shop.throttle import throttle

from .forms import CheckoutAddressForm
from .models import Order, OrderItem


def _parse_cart(raw):
    try:
        data = json.loads(raw or "[]")
        if not isinstance(data, list) or len(data) > 50:
            return []
        return data
    except (TypeError, ValueError):
        return []


@login_required
@require_POST
@throttle("checkout", limit=30, window=600)
def checkout(request):
    """Etapa 1: revisar pedido e endereço. Etapa 2 (action=pay): cria o pedido e vai pro gateway."""
    if not request.user.email_verified:
        messages.warning(request, "Confirme seu e-mail para finalizar a compra. Enviamos o link quando você se cadastrou.")
        return redirect("accounts:dashboard")

    cart_raw = request.POST.get("cart", "[]")
    coupon_code = request.POST.get("coupon", "").strip()[:30]
    quote = build_quote(_parse_cart(cart_raw), coupon_code)

    if not quote.lines:
        messages.error(request, "Seu carrinho está vazio ou os itens não estão mais disponíveis.")
        return redirect("shop:home")

    action = request.POST.get("action", "review")
    if action == "pay":
        form = CheckoutAddressForm(request.POST, instance=request.user)
        if form.is_valid():
            if quote.errors:
                # Preço/estoque mudou desde que o cliente montou o carrinho: mostra de novo antes de cobrar
                messages.warning(request, " ".join(quote.errors))
            else:
                user = form.save()
                with transaction.atomic():
                    order = Order.objects.create(
                        user=user, subtotal=quote.subtotal, discount=quote.discount,
                        shipping=quote.shipping, total=quote.total,
                        coupon_code=quote.coupon.code if quote.coupon else "",
                        ship_name=user.full_name, ship_phone=user.phone, ship_address=user.address_line,
                    )
                    OrderItem.objects.bulk_create([
                        OrderItem(order=order, product=l.product, name=l.product.name, emoji=l.product.emoji,
                                  unit_price=l.product.price, quantity=l.qty)
                        for l in quote.lines
                    ])
                try:
                    url = pay.create_checkout(order)
                except pay.GatewayError as exc:
                    messages.error(request, str(exc))
                    return redirect("orders:detail", public_id=order.public_id)
                return redirect(url)
    else:
        form = CheckoutAddressForm(instance=request.user)

    return render(request, "orders/checkout.html", {
        "quote": quote, "form": form, "cart_raw": json.dumps(_parse_cart(cart_raw)), "coupon": coupon_code,
    })


@login_required
def order_list(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items")
    return render(request, "orders/list.html", {"orders": orders})


def _own_order(request, public_id):
    # Sempre filtra por usuário: pedido de outra conta responde 404 (não revela que existe)
    return get_object_or_404(Order.objects.prefetch_related("items", "payments"),
                             public_id=public_id, user=request.user)


@login_required
def order_detail(request, public_id):
    return render(request, "orders/detail.html", {"order": _own_order(request, public_id)})


@login_required
def confirmation(request, public_id):
    """Página de retorno do gateway. O status mostrado vem do banco/gateway, nunca da URL."""
    order = _own_order(request, public_id)
    payment_id = request.GET.get("payment_id") or request.GET.get("collection_id")
    if order.status != Order.Status.PAID and payment_id and payment_id.isdigit():
        try:
            pay.sync_payment(payment_id)
            order.refresh_from_db()
        except pay.GatewayError:
            pass  # o webhook atualiza em seguida
    order = _own_order(request, public_id)
    return render(request, "orders/confirmation.html", {"order": order})


@login_required
@require_POST
@throttle("repay", limit=10, window=600)
def repay(request, public_id):
    order = _own_order(request, public_id)
    if not order.can_pay:
        raise Http404()
    try:
        return redirect(pay.create_checkout(order))
    except pay.GatewayError as exc:
        messages.error(request, str(exc))
        return redirect("orders:detail", public_id=order.public_id)
