from django.contrib import admin

from payments.models import Payment

from .models import Order, OrderItem


class ItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    can_delete = False
    readonly_fields = ("product", "name", "emoji", "unit_price", "quantity")

    def has_add_permission(self, request, obj=None):
        return False


class PaymentInline(admin.TabularInline):
    model = Payment
    extra = 0
    can_delete = False
    fields = ("gateway_payment_id", "status", "status_detail", "method", "installments", "amount", "note", "created_at")
    readonly_fields = fields

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("code", "user", "status", "fulfillment", "total", "created_at", "paid_at")
    list_filter = ("status", "fulfillment", "created_at")
    search_fields = ("user__email", "user__full_name", "ship_name", "tracking_code")
    date_hierarchy = "created_at"
    inlines = [ItemInline, PaymentInline]
    actions = ["mark_preparing", "mark_shipped", "mark_delivered"]

    # O status financeiro só muda via gateway; o painel controla apenas a entrega.
    readonly_fields = ("public_id", "user", "status", "subtotal", "discount", "shipping", "total", "coupon_code",
                       "ship_name", "ship_phone", "ship_address", "created_at", "paid_at")
    fields = ("public_id", "user", "status", "fulfillment", "tracking_code", "subtotal", "discount", "shipping",
              "total", "coupon_code", "ship_name", "ship_phone", "ship_address", "created_at", "paid_at")

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def _set(self, request, qs, value, label):
        n = qs.filter(status=Order.Status.PAID).update(fulfillment=value)
        self.message_user(request, f"{n} pedido(s) pago(s) marcados como {label}.")

    @admin.action(description="Marcar como Em separação")
    def mark_preparing(self, request, qs):
        self._set(request, qs, Order.Fulfillment.PREPARING, "em separação")

    @admin.action(description="Marcar como Enviado")
    def mark_shipped(self, request, qs):
        self._set(request, qs, Order.Fulfillment.SHIPPED, "enviados")

    @admin.action(description="Marcar como Entregue")
    def mark_delivered(self, request, qs):
        self._set(request, qs, Order.Fulfillment.DELIVERED, "entregues")
