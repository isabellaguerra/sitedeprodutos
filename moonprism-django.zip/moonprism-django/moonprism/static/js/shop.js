/* Moon Prism Shop — comportamento do front-end.
   Preços, frete, cupom e estoque são SEMPRE recalculados no servidor no checkout;
   os valores aqui servem só para exibir o carrinho. */
(function () {
  'use strict';
  var CFG = window.MOON || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var csrf = function () { var m = $('meta[name="csrf-token"]'); return m ? m.content : ''; };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };
  var brl = function (cents) { return 'R$ ' + (cents / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2}); };
  var toCents = function (v) { return Math.round(parseFloat(v) * 100); };

  // ── Notificações ─────────────────────────────────────────
  var notifTimer, toastTimer;
  function showNotif(txt, ico) {
    clearTimeout(notifTimer);
    $('#n-ico').textContent = ico || '✨';
    $('#n-txt').textContent = txt;
    $('#notif').classList.add('show');
    notifTimer = setTimeout(function () { $('#notif').classList.remove('show'); }, 3200);
  }
  function showToast(txt) {
    clearTimeout(toastTimer);
    var t = $('#toast'); t.textContent = txt; t.classList.add('show');
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 3000);
  }

  // ── Marquee ──────────────────────────────────────────────
  var mItems = ['✨ Frete Grátis acima de R$' + Math.round(CFG.freeFrom || 199), '🌙 Novas coleções toda semana', '💎 Produtos exclusivos', '🌸 Embalagem kawaii de presente', '⭐ Qualidade mágica garantida', '🐰 Itens fofinhos e delicados', '🎀 Sailor Moon universe', '🔮 Magia em cada detalhe'];
  ['mtrack', 'mtrack2'].forEach(function (id) {
    var el = document.getElementById(id); if (!el) return;
    el.innerHTML = mItems.concat(mItems).map(function (t) { return '<span class="m-item">' + esc(t) + '<span class="m-dot">◆</span></span>'; }).join('');
  });

  // ── Dados dos produtos (quando a página tem) ─────────────
  var catalog = {};
  var pd = document.getElementById('productsData');
  if (pd) { try { JSON.parse(pd.textContent).forEach(function (p) { catalog[p.id] = p; }); } catch (e) {} }
  var isHome = !!$('#catPills');

  // ── Carrinho ─────────────────────────────────────────────
  var cart = {};
  var coupon = null;
  function loadCart() {
    try {
      var raw = JSON.parse(localStorage.getItem('moon_cart') || '{}');
      Object.keys(raw).forEach(function (k) {
        var it = raw[k], id = parseInt(it && it.id, 10), qty = parseInt(it && it.qty, 10), price = parseFloat(it && it.price);
        if (!id || !(qty >= 1) || !(price > 0)) return;
        cart[id] = {id: id, name: String(it.name || '').slice(0, 120), emoji: String(it.emoji || '✨').slice(0, 8), price: price, stock: parseInt(it.stock, 10) || 99, qty: Math.min(qty, 20)};
      });
      var c = JSON.parse(localStorage.getItem('moon_coupon') || 'null');
      if (c && c.code && c.percent > 0 && c.percent <= 90) coupon = {code: String(c.code).slice(0, 30), percent: parseInt(c.percent, 10)};
    } catch (e) { cart = {}; }
    // atualiza com os dados oficiais da página, se houver
    Object.keys(cart).forEach(function (id) {
      var p = catalog[id];
      if (p) { cart[id].name = p.name; cart[id].emoji = p.emoji; cart[id].price = parseFloat(p.price); cart[id].stock = p.stock; cart[id].qty = Math.min(cart[id].qty, Math.max(p.stock, 1)); }
      else if (isHome) { delete cart[id]; }
    });
  }
  function saveCart() {
    try { localStorage.setItem('moon_cart', JSON.stringify(cart)); localStorage.setItem('moon_coupon', JSON.stringify(coupon)); } catch (e) {}
  }
  function totals() {
    var sub = 0; Object.keys(cart).forEach(function (id) { sub += toCents(cart[id].price) * cart[id].qty; });
    var disc = coupon ? Math.round(sub * coupon.percent / 100) : 0;
    var free = Math.round((CFG.freeFrom || 199) * 100);
    var ship = (sub === 0 || sub >= free) ? 0 : Math.round((CFG.flat || 15.9) * 100);
    return {sub: sub, disc: disc, ship: ship, total: sub - disc + ship, free: free};
  }
  function count() { return Object.keys(cart).reduce(function (a, id) { return a + cart[id].qty; }, 0); }

  function renderCart() {
    var n = count(), items = $('#cartItems'), ftr = $('#cartFtr');
    $('#cart-badge').textContent = n;
    if (n === 0) {
      items.innerHTML = '<div class="empty"><span class="empty-ico">🌙</span><p><strong>Seu carrinho está vazio...</strong></p><p style="margin-top:.5rem;">Que tal adicionar um item mágico? ✨</p></div>';
      ftr.style.display = 'none'; return;
    }
    ftr.style.display = '';
    items.innerHTML = Object.keys(cart).map(function (id) {
      var it = cart[id];
      return '<div class="ci"><div class="ci-ico">' + esc(it.emoji) + '</div><div class="ci-info"><div class="ci-name">' + esc(it.name) + '</div><div class="ci-price">' + brl(toCents(it.price) * it.qty) + '</div></div>' +
        '<div class="qty-ctrl"><button class="qty-b" type="button" data-qty="-1" data-id="' + it.id + '" aria-label="Diminuir">−</button><span class="qty-n">' + it.qty + '</span><button class="qty-b" type="button" data-qty="1" data-id="' + it.id + '" aria-label="Aumentar">+</button></div>' +
        '<button class="ci-del" type="button" data-del="' + it.id + '" aria-label="Remover">🗑️</button></div>';
    }).join('');
    var t = totals();
    $('#sub-total').textContent = brl(t.sub);
    $('#total-val').textContent = brl(t.total);
    $('#disc-row').style.display = coupon ? '' : 'none';
    if (coupon) { $('#disc-code').textContent = coupon.code + ' (' + coupon.percent + '%)'; $('#disc-val').textContent = '− ' + brl(t.disc); }
    if (t.ship === 0) {
      $('#frete-val').innerHTML = '<span class="free">Grátis! 🎉</span>';
      $('#ship-bar-wrap').style.display = 'none'; $('#ship-hint').textContent = '';
    } else {
      $('#frete-val').textContent = brl(t.ship);
      $('#ship-bar-wrap').style.display = '';
      $('#ship-fill').style.width = Math.min(100, t.sub / t.free * 100) + '%';
      $('#ship-hint').textContent = '✨ Faltam ' + brl(t.free - t.sub) + ' para frete grátis!';
    }
  }

  function addToCart(id) {
    var p = catalog[id] || cart[id];
    if (!p) return;
    var stock = p.stock === undefined ? 99 : p.stock;
    var cur = cart[id] ? cart[id].qty : 0;
    if (cur >= Math.min(stock, 20)) { showNotif('Limite de unidades atingido para este item.', '🔮'); return; }
    if (cart[id]) cart[id].qty++;
    else cart[id] = {id: id, name: p.name, emoji: p.emoji, price: parseFloat(p.price), stock: stock, qty: 1};
    saveCart(); renderCart();
    showToast(p.emoji + ' ' + p.name + ' adicionado!');
    var b = $('#cart-badge'); b.style.transform = 'scale(1.5)'; setTimeout(function () { b.style.transform = ''; }, 300);
  }

  function openCart() {
    $('#cartOv').classList.add('open'); $('#cartDr').classList.add('open');
    $('#cartDr').setAttribute('aria-hidden', 'false'); document.body.style.overflow = 'hidden';
  }
  function closeCart() {
    $('#cartOv').classList.remove('open'); $('#cartDr').classList.remove('open');
    $('#cartDr').setAttribute('aria-hidden', 'true'); document.body.style.overflow = '';
  }

  function postJSON(url, body) {
    return fetch(url, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrf()}, body: JSON.stringify(body)})
      .then(function (r) { return r.json().catch(function () { return {ok: false, error: 'Erro inesperado.'}; }); });
  }

  function applyPromo() {
    var code = $('#promoInput').value.trim();
    if (!code) return;
    postJSON(CFG.couponUrl, {code: code}).then(function (r) {
      if (r.ok) { coupon = {code: r.code, percent: r.percent}; saveCart(); renderCart(); $('#promoInput').value = ''; showNotif('🎉 Cupom aplicado! ' + r.percent + '% de desconto!', '💎'); }
      else showNotif(r.error || 'Código inválido.', '🔮');
    }).catch(function () { showNotif('Não foi possível validar o cupom agora.', '🔮'); });
  }

  function checkout() {
    var items = Object.keys(cart).map(function (id) { return {id: cart[id].id, qty: cart[id].qty}; });
    if (!items.length) return;
    if (!CFG.auth) {
      showNotif('Entre na sua conta para finalizar a compra 🌸', '💜');
      setTimeout(function () { window.location.href = CFG.loginUrl + '?next=' + encodeURIComponent(window.location.pathname); }, 900);
      return;
    }
    $('#coCart').value = JSON.stringify(items);
    $('#coCoupon').value = coupon ? coupon.code : '';
    $('#checkoutForm').submit();
  }

  // ── Eventos globais (delegação) ──────────────────────────
  document.addEventListener('click', function (e) {
    var t = e.target;
    var add = t.closest('[data-add]'); if (add) { addToCart(parseInt(add.dataset.add, 10)); return; }
    if (t.closest('#openCartBtn, [data-open-cart]')) { openCart(); return; }
    if (t.closest('#closeCartBtn') || t.id === 'cartOv') { closeCart(); return; }
    var q = t.closest('[data-qty]');
    if (q) {
      var id = parseInt(q.dataset.id, 10), d = parseInt(q.dataset.qty, 10);
      if (cart[id]) { cart[id].qty = Math.max(1, Math.min(cart[id].qty + d, Math.min(cart[id].stock || 20, 20))); saveCart(); renderCart(); }
      return;
    }
    var del = t.closest('[data-del]'); if (del) { delete cart[parseInt(del.dataset.del, 10)]; saveCart(); renderCart(); return; }
    if (t.closest('#clearCartBtn')) { cart = {}; coupon = null; saveCart(); renderCart(); showNotif('Carrinho limpo!', '🌙'); return; }
    if (t.closest('#applyPromoBtn')) { applyPromo(); return; }
    if (t.closest('#checkoutBtn')) { checkout(); return; }
    var fl = t.closest('[data-close-flash]'); if (fl) { fl.parentElement.remove(); return; }
    var w = t.closest('[data-wish]'); if (w) { toggleWish(w); return; }
    var ub = t.closest('#userBtn');
    var um = $('#userMenu');
    if (um) { var open = ub ? um.classList.toggle('open') : false; if (!ub) um.classList.remove('open'); if ($('#userBtn')) $('#userBtn').setAttribute('aria-expanded', open ? 'true' : 'false'); }
    if (t.closest('#menuBtn')) { var mn = $('#mobileNav'), o = mn.classList.toggle('open'); $('#menuBtn').setAttribute('aria-expanded', o); return; }
    var link = t.closest('[data-cat-link]');
    if (link && isHome && link.pathname === window.location.pathname) {
      e.preventDefault(); setCat(link.dataset.catLink, true);
      var mn2 = $('#mobileNav'); if (mn2) mn2.classList.remove('open');
    }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeCart(); });

  // ── Favoritos (salvos na conta) ──────────────────────────
  function toggleWish(btn) {
    if (!CFG.auth) {
      showNotif('Entre na sua conta para salvar favoritos 💜', '🌸');
      setTimeout(function () { window.location.href = CFG.loginUrl + '?next=' + encodeURIComponent(window.location.pathname); }, 900);
      return;
    }
    var id = btn.dataset.wish;
    fetch(CFG.wishUrl.replace(/0\/$/, id + '/'), {method: 'POST', credentials: 'same-origin', headers: {'X-CSRFToken': csrf()}})
      .then(function (r) { return r.json(); }).then(function (r) {
        if (!r.ok) { showNotif('Não foi possível salvar agora.', '🔮'); return; }
        btn.dataset.wished = r.wished ? '1' : '0'; btn.textContent = r.wished ? '💜' : '🤍';
        btn.style.transform = 'scale(1.35)'; setTimeout(function () { btn.style.transform = ''; }, 300);
        if (r.wished) showNotif('Adicionado aos favoritos!', '🌸');
        else { var g = btn.closest('#productsGrid'); if (g && g.dataset.static) { btn.closest('.card').remove(); } }
      }).catch(function () { showNotif('Sem conexão. Tente de novo.', '🔮'); });
  }

  // ── Filtros e busca (home) ───────────────────────────────
  var curCat = 'all', curQ = '';
  var SPECIAL = {'mais-vendidos': 'bestseller', 'promocoes': 'oferta'};
  function applyFilter() {
    var grid = $('#productsGrid'); if (!grid || !isHome) return;
    var shown = 0, q = curQ.toLowerCase();
    $$('.card', grid).forEach(function (c) {
      var okCat = curCat === 'all' || c.dataset.cat === curCat || (SPECIAL[curCat] && c.dataset.tag === SPECIAL[curCat]);
      var okQ = !q || c.dataset.search.indexOf(q) !== -1;
      c.classList.toggle('hidden', !(okCat && okQ)); if (okCat && okQ) shown++;
    });
    $('#prodCount').textContent = shown + ' itens encantados';
    var nr = $('#noResults'); if (nr) nr.hidden = shown !== 0 || !$$('.card', grid).length;
  }
  function setCat(cat, scroll) {
    curCat = cat;
    $$('#catPills [data-cat]').forEach(function (p) { p.className = 'pill ' + (p.dataset.cat === cat ? 'pill-a' : 'pill-d'); });
    $$('.nav [data-cat-link]').forEach(function (a) { a.classList.toggle('act', a.dataset.catLink === cat); });
    applyFilter();
    if (scroll) { var s = document.getElementById('produtos'); if (s) s.scrollIntoView({behavior: 'smooth'}); }
    try { history.replaceState(null, '', cat === 'all' ? window.location.pathname : '?cat=' + encodeURIComponent(cat)); } catch (e) {}
  }
  if (isHome) {
    $('#catPills').addEventListener('click', function (e) { var p = e.target.closest('[data-cat]'); if (p) setCat(p.dataset.cat, false); });
    ['searchInput', 'searchMobile'].forEach(function (id) {
      var el = document.getElementById(id); if (!el) return;
      el.addEventListener('input', function () { curQ = el.value; applyFilter(); });
      el.form && el.form.addEventListener('submit', function (e) { e.preventDefault(); curQ = el.value; applyFilter(); var s = document.getElementById('produtos'); if (s) s.scrollIntoView({behavior: 'smooth'}); });
    });
    var g = $('#productsGrid');
    curQ = g.dataset.initialQ || '';
    ['searchInput', 'searchMobile'].forEach(function (id) { var el = document.getElementById(id); if (el) el.value = curQ; });
    var ic = g.dataset.initialCat || 'all';
    var valid = ic === 'all' || SPECIAL[ic] || $('#catPills [data-cat="' + ic.replace(/[^a-z0-9-]/gi, '') + '"]');
    setCat(valid ? ic : 'all', false);
  }

  // ── Newsletter ───────────────────────────────────────────
  var nl = $('#nlForm');
  if (nl) nl.addEventListener('submit', function (e) {
    e.preventDefault();
    var email = $('#nlEmail').value.trim(), msg = $('#nlMsg');
    if (!email || !$('#nlEmail').checkValidity()) { msg.textContent = 'Digite um e-mail válido 🌸'; return; }
    var fd = new FormData(); fd.append('email', email);
    fetch(CFG.newsletterUrl, {method: 'POST', credentials: 'same-origin', headers: {'X-CSRFToken': csrf()}, body: fd})
      .then(function (r) { return r.json(); }).then(function (r) {
        if (r.ok) { msg.textContent = '🌸 Inscrição realizada! Bem-vinda ao clube mágico!'; nl.reset(); }
        else msg.textContent = r.error || 'Não foi possível inscrever agora.';
      }).catch(function () { msg.textContent = 'Sem conexão. Tente de novo.'; });
  });

  // ── Efeitos visuais originais ────────────────────────────
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduce) {
    var st = document.createElement('style');
    st.textContent = '@keyframes burst{0%{opacity:1;transform:scale(0) rotate(0deg);}50%{opacity:1;transform:scale(1.5) rotate(180deg) translateY(-20px);}100%{opacity:0;transform:scale(.5) rotate(360deg) translateY(-40px);}}@keyframes spk{0%{transform:translateY(0) rotate(0deg);opacity:0;}10%{opacity:.7;}90%{opacity:.7;}100%{transform:translateY(-110vh) rotate(360deg);opacity:0;}}';
    document.head.appendChild(st);
    var emojis = ['✨', '⭐', '💫', '🌸', '💜'];
    var grid2 = $('#productsGrid');
    if (grid2) grid2.addEventListener('mouseover', function (e) {
      var card = e.target.closest('.card'); if (!card || card.contains(e.relatedTarget)) return;
      var r = card.getBoundingClientRect();
      for (var i = 0; i < 4; i++) {
        var el = document.createElement('div');
        el.style.cssText = 'position:fixed;left:' + (r.left + Math.random() * r.width) + 'px;top:' + (r.top + Math.random() * r.height) + 'px;font-size:' + (10 + Math.random() * 14) + 'px;pointer-events:none;z-index:999;animation:burst .9s ease forwards;';
        el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
        document.body.appendChild(el); setTimeout(function (x) { x.remove(); }.bind(null, el), 950);
      }
    });
    var spk = ['✨', '⭐', '🌸', '💫', '🔮', '💜', '🌙', '💎', '🌟', '🎀'], box = $('#sparkle-container');
    for (var i = 0; i < 20; i++) {
      var s = document.createElement('div');
      s.style.cssText = 'position:absolute;left:' + Math.random() * 100 + '%;bottom:-30px;font-size:' + (8 + Math.random() * 12) + 'px;pointer-events:none;opacity:0;animation:spk ' + (8 + Math.random() * 8) + 's linear infinite;animation-delay:' + Math.random() * 10 + 's;';
      s.textContent = spk[Math.floor(Math.random() * spk.length)]; box.appendChild(s);
    }
  }

  // mensagens do servidor somem sozinhas
  setTimeout(function () { $$('.flash').forEach(function (f) { f.remove(); }); }, 7000);

  loadCart(); renderCart();
})();
