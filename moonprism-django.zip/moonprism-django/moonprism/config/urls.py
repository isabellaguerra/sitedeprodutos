from django.conf import settings
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path(settings.ADMIN_URL, admin.site.urls),
    path("conta/", include("accounts.urls")),
    path("pedidos/", include("orders.urls")),
    path("pagamentos/", include("payments.urls")),
    path("", include("shop.urls")),
]

handler404 = "shop.views.error_404"
handler403 = "shop.views.error_403"
handler500 = "shop.views.error_500"
