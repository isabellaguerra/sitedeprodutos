def username_from_request(request, credentials=None):
    """Chave de bloqueio do django-axes: e-mail em minúsculas (impede burlar variando maiúsculas)."""
    value = ""
    if credentials:
        value = credentials.get("username") or credentials.get("email") or ""
    if not value and request is not None:
        value = request.POST.get("username", "")
    return str(value).strip().lower() or None
