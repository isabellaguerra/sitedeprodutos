from django.contrib.auth import views as auth_views
from django.urls import path, reverse_lazy

from . import views

app_name = "accounts"

urlpatterns = [
    path("entrar/", views.MoonLoginView.as_view(), name="login"),
    # Logout só aceita POST (proteção contra logout forçado via link)
    path("sair/", auth_views.LogoutView.as_view(), name="logout"),
    path("cadastro/", views.signup, name="signup"),
    path("confirmar-email/<str:token>/", views.verify_email, name="verify_email"),
    path("reenviar-confirmacao/", views.resend_verification, name="resend_verification"),

    path("", views.dashboard, name="dashboard"),
    path("perfil/", views.profile, name="profile"),
    path("senha/alterar/", views.MoonPasswordChangeView.as_view(), name="password_change"),

    path("senha/recuperar/", views.MoonPasswordResetView.as_view(), name="password_reset"),
    path("senha/recuperar/enviado/", auth_views.PasswordResetDoneView.as_view(
        template_name="accounts/password_reset_done.html"), name="password_reset_done"),
    path("senha/redefinir/<uidb64>/<token>/", auth_views.PasswordResetConfirmView.as_view(
        template_name="accounts/password_reset_confirm.html",
        success_url=reverse_lazy("accounts:password_reset_complete")), name="password_reset_confirm"),
    path("senha/redefinida/", auth_views.PasswordResetCompleteView.as_view(
        template_name="accounts/password_reset_complete.html"), name="password_reset_complete"),
]
