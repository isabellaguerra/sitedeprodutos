import re

from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.forms import AuthenticationForm

from .models import User


def only_digits(value):
    return re.sub(r"\D", "", value or "")


class LoginForm(AuthenticationForm):
    username = forms.EmailField(label="E-mail", widget=forms.EmailInput(
        attrs={"autocomplete": "email", "placeholder": "seu@email.com", "autofocus": True}))
    password = forms.CharField(label="Senha", strip=False, widget=forms.PasswordInput(
        attrs={"autocomplete": "current-password", "placeholder": "Sua senha"}))
    error_messages = {
        "invalid_login": "E-mail ou senha incorretos. Confira os dados e tente de novo.",
        "inactive": "Esta conta está desativada. Fale com o suporte.",
    }


class SignUpForm(forms.ModelForm):
    password1 = forms.CharField(label="Senha", strip=False, widget=forms.PasswordInput(
        attrs={"autocomplete": "new-password", "placeholder": "Mínimo de 10 caracteres"}),
        help_text="Use pelo menos 10 caracteres, sem ser uma senha comum nem só números.")
    password2 = forms.CharField(label="Confirmar senha", strip=False, widget=forms.PasswordInput(
        attrs={"autocomplete": "new-password", "placeholder": "Repita a senha"}))

    class Meta:
        model = User
        fields = ["full_name", "email"]
        widgets = {
            "full_name": forms.TextInput(attrs={"autocomplete": "name", "placeholder": "Seu nome completo"}),
            "email": forms.EmailInput(attrs={"autocomplete": "email", "placeholder": "seu@email.com"}),
        }

    def clean_full_name(self):
        name = " ".join(self.cleaned_data["full_name"].split())
        if len(name) < 3 or " " not in name:
            raise forms.ValidationError("Informe seu nome e sobrenome.")
        return name

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Já existe uma conta com esse e-mail. Tente entrar ou recuperar a senha.")
        return email

    def clean(self):
        cleaned = super().clean()
        p1, p2 = cleaned.get("password1"), cleaned.get("password2")
        if p1 and p2 and p1 != p2:
            self.add_error("password2", "As senhas não são iguais.")
        elif p1:
            candidate = User(email=cleaned.get("email", ""), full_name=cleaned.get("full_name", ""))
            try:
                password_validation.validate_password(p1, candidate)
            except forms.ValidationError as exc:
                self.add_error("password1", exc)
        return cleaned

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


class ProfileForm(forms.ModelForm):
    # aceita "11700-000" com máscara; clean_cep() guarda só os dígitos
    cep = forms.CharField(label="CEP", max_length=9, required=False, widget=forms.TextInput(
        attrs={"inputmode": "numeric", "placeholder": "00000-000", "autocomplete": "postal-code"}))

    class Meta:
        model = User
        fields = ["full_name", "phone", "cep", "street", "number", "complement", "district", "city", "state"]
        widgets = {
            "phone": forms.TextInput(attrs={"inputmode": "tel", "placeholder": "(13) 99999-9999", "autocomplete": "tel"}),
            "street": forms.TextInput(attrs={"autocomplete": "address-line1"}),
            "number": forms.TextInput(attrs={"autocomplete": "off"}),
            "district": forms.TextInput(attrs={"autocomplete": "address-level3"}),
            "city": forms.TextInput(attrs={"autocomplete": "address-level2"}),
        }

    def clean_full_name(self):
        name = " ".join(self.cleaned_data["full_name"].split())
        if len(name) < 3:
            raise forms.ValidationError("Informe seu nome completo.")
        return name

    def clean_phone(self):
        digits = only_digits(self.cleaned_data.get("phone"))
        if digits and len(digits) not in (10, 11):
            raise forms.ValidationError("Telefone inválido. Use DDD + número, ex.: (13) 99999-9999.")
        return digits

    def clean_cep(self):
        digits = only_digits(self.cleaned_data.get("cep"))
        if digits and len(digits) != 8:
            raise forms.ValidationError("CEP inválido. Use 8 números, ex.: 11700-000.")
        return digits

    def clean(self):
        cleaned = super().clean()
        address = ["cep", "street", "number", "district", "city", "state"]
        filled = [bool(cleaned.get(f)) for f in address]
        if any(filled) and not all(filled):
            for f in address:
                if not cleaned.get(f) and f not in self.errors:
                    self.add_error(f, "Preencha o endereço completo (complemento é opcional).")
        return cleaned
