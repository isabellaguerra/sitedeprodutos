from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import (
    LoginView, PasswordChangeView, PasswordResetView,
)
from django.core.mail import send_mail
from django.shortcuts import redirect, render
from django.template.loader import render_to_string
from django.urls import reverse, reverse_lazy
from django.utils.decorators import method_decorator
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from shop.throttle import throttle

from .forms import LoginForm, ProfileForm, SignUpForm
from . import tokens

User = get_user_model()


def send_verification_email(request, user):
    link = settings.SITE_URL + reverse("accounts:verify_email", args=[tokens.make_token(user)])
    body = render_to_string("accounts/email/verify_email.txt", {"user": user, "link": link})
    send_mail("Confirme seu e-mail — Moon Prism Shop ✨", body, settings.DEFAULT_FROM_EMAIL, [user.email])


class MoonLoginView(LoginView):
    form_class = LoginForm
    template_name = "accounts/login.html"
    redirect_authenticated_user = True


@throttle("signup", limit=8, window=3600)
def signup(request):
    if request.user.is_authenticated:
        return redirect("shop:home")
    form = SignUpForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        send_verification_email(request, user)
        login(request, user, backend="django.contrib.auth.backends.ModelBackend")
        messages.success(request, "Conta criada! Enviamos um link para confirmar seu e-mail. 💌")
        nxt = request.POST.get("next") or request.GET.get("next")
        if nxt and url_has_allowed_host_and_scheme(nxt, allowed_hosts={request.get_host()},
                                                   require_https=request.is_secure()):
            return redirect(nxt)
        return redirect("accounts:dashboard")
    return render(request, "accounts/signup.html", {"form": form, "next": request.GET.get("next", "")})


def verify_email(request, token):
    data = tokens.read_token(token)
    user = User.objects.filter(pk=data[0], email=data[1]).first() if data else None
    if user:
        if not user.email_verified:
            user.email_verified = True
            user.save(update_fields=["email_verified"])
        messages.success(request, "E-mail confirmado! Agora você já pode finalizar compras. 🌙")
    else:
        messages.error(request, "Link inválido ou expirado. Peça um novo na sua conta.")
    return redirect("accounts:dashboard" if request.user.is_authenticated else "accounts:login")


@login_required
@require_POST
@throttle("resend", limit=3, window=3600)
def resend_verification(request):
    if request.user.email_verified:
        messages.info(request, "Seu e-mail já está confirmado.")
    else:
        send_verification_email(request, request.user)
        messages.success(request, "Enviamos um novo link para o seu e-mail. 💌")
    return redirect("accounts:dashboard")


@login_required
def dashboard(request):
    from orders.models import Order
    orders = Order.objects.filter(user=request.user)
    return render(request, "accounts/dashboard.html", {
        "orders_count": orders.count(),
        "paid_count": orders.filter(status=Order.Status.PAID).count(),
        "last_orders": orders.order_by("-created_at")[:3],
    })


@login_required
def profile(request):
    form = ProfileForm(request.POST or None, instance=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Dados atualizados com sucesso! ✨")
        return redirect("accounts:profile")
    return render(request, "accounts/profile.html", {"form": form})


class MoonPasswordChangeView(PasswordChangeView):
    template_name = "accounts/password_change.html"
    success_url = reverse_lazy("accounts:dashboard")

    def form_valid(self, form):
        messages.success(self.request, "Senha alterada com sucesso! 🔒")
        return super().form_valid(form)


@method_decorator(throttle("pwreset", limit=5, window=3600), name="dispatch")
class MoonPasswordResetView(PasswordResetView):
    template_name = "accounts/password_reset.html"
    email_template_name = "accounts/email/password_reset_email.txt"
    subject_template_name = "accounts/email/password_reset_subject.txt"
    success_url = reverse_lazy("accounts:password_reset_done")
    from_email = settings.DEFAULT_FROM_EMAIL

    def form_valid(self, form):
        # Link do e-mail usa SITE_URL (e não o cabeçalho Host da requisição)
        self.extra_email_context = {"site_url": settings.SITE_URL}
        return super().form_valid(form)
