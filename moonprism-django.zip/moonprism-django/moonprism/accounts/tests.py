import re

from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from shop.testing import PASSWORD, make_user

from .models import User

STRONG = "Estrela-Cadente-9981"


@override_settings(SITE_URL="https://loja.test")
class SignupAndVerifyTests(TestCase):
    def setUp(self):
        cache.clear()

    def test_signup_hashes_password_logs_in_and_sends_verification(self):
        r = self.client.post(reverse("accounts:signup"), {
            "full_name": "Maria Lua", "email": "Maria@Example.com", "password1": STRONG, "password2": STRONG})
        self.assertRedirects(r, reverse("accounts:dashboard"))
        user = User.objects.get(email="maria@example.com")  # e-mail normalizado
        self.assertTrue(user.password.startswith("pbkdf2_sha256$"))
        self.assertNotIn(STRONG, user.password)
        self.assertFalse(user.email_verified)
        self.assertFalse(user.is_staff)
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("https://loja.test/conta/confirmar-email/", mail.outbox[0].body)
        self.assertEqual(self.client.get(reverse("accounts:dashboard")).status_code, 200)

    def test_weak_and_mismatched_passwords_rejected(self):
        url = reverse("accounts:signup")
        for pw in ("12345678", "senha", "password123"):
            r = self.client.post(url, {"full_name": "Maria Lua", "email": "m@example.com", "password1": pw, "password2": pw})
            self.assertEqual(r.status_code, 200)
        r = self.client.post(url, {"full_name": "Maria Lua", "email": "m@example.com", "password1": STRONG, "password2": STRONG + "x"})
        self.assertContains(r, "não são iguais")
        self.assertFalse(User.objects.filter(email="m@example.com").exists())

    def test_duplicate_email_case_insensitive_and_invalid_data(self):
        make_user("ana@example.com")
        r = self.client.post(reverse("accounts:signup"), {"full_name": "Outra Ana", "email": "ANA@example.com", "password1": STRONG, "password2": STRONG})
        self.assertContains(r, "Já existe uma conta")
        r = self.client.post(reverse("accounts:signup"), {"full_name": "Ana", "email": "nao-e-email", "password1": STRONG, "password2": STRONG})
        self.assertEqual(User.objects.count(), 1)

    def test_email_verification_flow(self):
        self.client.post(reverse("accounts:signup"), {"full_name": "Maria Lua", "email": "m@example.com", "password1": STRONG, "password2": STRONG})
        link = re.search(r"https://loja.test(/conta/confirmar-email/\S+)", mail.outbox[0].body).group(1)
        self.client.get(link)
        self.assertTrue(User.objects.get(email="m@example.com").email_verified)

    def test_tampered_or_stale_verification_token(self):
        user = make_user("v@example.com", verified=False)
        r = self.client.get(reverse("accounts:verify_email", args=["lixo:lixo:lixo"]), follow=True)
        user.refresh_from_db()
        self.assertFalse(user.email_verified)
        from . import tokens
        token = tokens.make_token(user)
        user.email = "novo@example.com"; user.save()  # e-mail mudou: token antigo morre
        self.client.get(reverse("accounts:verify_email", args=[token]))
        user.refresh_from_db()
        self.assertFalse(user.email_verified)

    def test_signup_open_redirect_blocked(self):
        r = self.client.post(reverse("accounts:signup") + "?next=https://evil.example/", {
            "full_name": "Maria Lua", "email": "o@example.com", "password1": STRONG, "password2": STRONG})
        self.assertRedirects(r, reverse("accounts:dashboard"))


class LoginTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = make_user("ana@example.com")

    def test_login_ok_case_insensitive_email(self):
        r = self.client.post(reverse("accounts:login"), {"username": "ANA@example.com", "password": PASSWORD})
        self.assertRedirects(r, "/", fetch_redirect_response=False)
        self.assertIn("_auth_user_id", self.client.session)

    def test_wrong_password_generic_message(self):
        r = self.client.post(reverse("accounts:login"), {"username": "ana@example.com", "password": "errada"})
        self.assertContains(r, "E-mail ou senha incorretos")
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_lockout_after_repeated_failures_even_with_right_password(self):
        for _ in range(5):
            self.client.post(reverse("accounts:login"), {"username": "ana@example.com", "password": "errada"})
        r = self.client.post(reverse("accounts:login"), {"username": "ana@example.com", "password": PASSWORD})
        self.assertEqual(r.status_code, 429)
        self.assertContains(r, "Muitas tentativas", status_code=429)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_login_next_open_redirect_blocked(self):
        r = self.client.post(reverse("accounts:login"), {"username": "ana@example.com", "password": PASSWORD, "next": "https://evil.example/"})
        self.assertRedirects(r, "/", fetch_redirect_response=False)

    def test_inactive_user_cannot_login(self):
        self.user.is_active = False; self.user.save()
        self.client.post(reverse("accounts:login"), {"username": "ana@example.com", "password": PASSWORD})
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_logout_requires_post(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse("accounts:logout")).status_code, 405)
        self.client.post(reverse("accounts:logout"))
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_session_cookie_flags(self):
        self.client.post(reverse("accounts:login"), {"username": "ana@example.com", "password": PASSWORD})
        c = self.client.cookies["sessionid"]
        self.assertTrue(c["httponly"])
        self.assertEqual(c["samesite"], "Lax")


@override_settings(SITE_URL="https://loja.test")
class PasswordResetTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = make_user("ana@example.com")

    def test_full_reset_flow(self):
        r = self.client.post(reverse("accounts:password_reset"), {"email": "ana@example.com"})
        self.assertRedirects(r, reverse("accounts:password_reset_done"))
        self.assertEqual(len(mail.outbox), 1)
        link = re.search(r"https://loja.test(/conta/senha/redefinir/\S+)", mail.outbox[0].body).group(1)
        r = self.client.get(link, follow=True)
        post_url = r.redirect_chain[-1][0]
        new = "Nova-Senha-Mágica-77"
        r = self.client.post(post_url, {"new_password1": new, "new_password2": new})
        self.assertRedirects(r, reverse("accounts:password_reset_complete"))
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password(new))
        # o link não pode ser reutilizado
        r = self.client.get(link, follow=True)
        self.assertContains(r, "Link inválido ou expirado")

    def test_unknown_email_gets_same_response_and_no_mail(self):
        r = self.client.post(reverse("accounts:password_reset"), {"email": "ninguem@example.com"})
        self.assertRedirects(r, reverse("accounts:password_reset_done"))
        self.assertEqual(len(mail.outbox), 0)

    def test_reset_rejects_weak_password(self):
        self.client.post(reverse("accounts:password_reset"), {"email": "ana@example.com"})
        link = re.search(r"https://loja.test(/conta/senha/redefinir/\S+)", mail.outbox[0].body).group(1)
        post_url = self.client.get(link, follow=True).redirect_chain[-1][0]
        r = self.client.post(post_url, {"new_password1": "12345678", "new_password2": "12345678"})
        self.assertEqual(r.status_code, 200)
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password(PASSWORD))


class AccountAreaTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = make_user("ana@example.com")

    def test_pages_require_login(self):
        for name in ("accounts:dashboard", "accounts:profile", "accounts:password_change", "orders:list", "shop:wishlist"):
            r = self.client.get(reverse(name))
            self.assertEqual(r.status_code, 302, name)
            self.assertIn(reverse("accounts:login"), r["Location"])

    def test_profile_update_and_validation(self):
        self.client.force_login(self.user)
        good = {"full_name": "Ana Souza", "phone": "(13) 99999-8888", "cep": "11700-000", "street": "Rua A", "number": "10",
                "complement": "", "district": "Centro", "city": "Praia Grande", "state": "SP"}
        r = self.client.post(reverse("accounts:profile"), good)
        self.assertRedirects(r, reverse("accounts:profile"))
        self.user.refresh_from_db()
        self.assertEqual((self.user.cep, self.user.phone), ("11700000", "13999998888"))
        bad = dict(good, cep="123", phone="12")
        r = self.client.post(reverse("accounts:profile"), bad)
        self.assertContains(r, "CEP inválido"); self.assertContains(r, "Telefone inválido")
        partial = dict(good, street="")
        self.assertContains(self.client.post(reverse("accounts:profile"), partial), "Preencha o endereço completo")

    def test_profile_cannot_change_email_or_privileges(self):
        self.client.force_login(self.user)
        self.client.post(reverse("accounts:profile"), {"full_name": "Ana Souza", "email": "hack@example.com",
                                                       "is_staff": "on", "is_superuser": "on", "email_verified": "on"})
        self.user.refresh_from_db()
        self.assertEqual(self.user.email, "ana@example.com")
        self.assertFalse(self.user.is_staff or self.user.is_superuser)

    def test_password_change(self):
        self.client.force_login(self.user)
        new = "Outra-Senha-Forte-55"
        r = self.client.post(reverse("accounts:password_change"), {"old_password": PASSWORD, "new_password1": new, "new_password2": new})
        self.assertRedirects(r, reverse("accounts:dashboard"))
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password(new))
        self.assertEqual(self.client.get(reverse("accounts:dashboard")).status_code, 200)  # sessão continua válida

    def test_resend_verification(self):
        u = make_user("nv@example.com", verified=False)
        self.client.force_login(u)
        self.client.post(reverse("accounts:resend_verification"))
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(self.client.get(reverse("accounts:resend_verification")).status_code, 405)
