from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import AdminUserCreationForm, UserChangeForm

from .models import User


class StaffUserCreationForm(AdminUserCreationForm):
    class Meta:
        model = User
        fields = ("email", "full_name")


class StaffUserChangeForm(UserChangeForm):
    class Meta:
        model = User
        fields = "__all__"


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    form = StaffUserChangeForm
    add_form = StaffUserCreationForm
    ordering = ("-date_joined",)
    list_display = ("email", "full_name", "email_verified", "is_active", "is_staff", "date_joined")
    list_filter = ("is_staff", "is_superuser", "is_active", "email_verified", "groups")
    search_fields = ("email", "full_name", "phone")
    readonly_fields = ("last_login", "date_joined")
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Dados pessoais", {"fields": ("full_name", "phone")}),
        ("Endereço", {"fields": ("cep", "street", "number", "complement", "district", "city", "state")}),
        ("Acesso", {"fields": ("email_verified", "is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Datas", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email", "full_name", "usable_password", "password1", "password2", "is_staff")}),
    )

    def get_readonly_fields(self, request, obj=None):
        ro = list(super().get_readonly_fields(request, obj))
        # Só superusuário mexe em permissões de administrador
        if not request.user.is_superuser:
            ro += ["is_superuser", "user_permissions", "groups"]
        return ro

    def has_delete_permission(self, request, obj=None):
        # Pedidos e pagamentos dependem do usuário: prefira desativar a excluir
        return request.user.is_superuser and super().has_delete_permission(request, obj)
