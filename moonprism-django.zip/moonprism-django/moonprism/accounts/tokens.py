"""Token assinado para confirmar e-mail (vale 3 dias; amarrado ao e-mail atual do usuário)."""
from django.core import signing

SALT = "moonprism.email-verification"
MAX_AGE = 60 * 60 * 24 * 3


def make_token(user):
    return signing.dumps({"uid": user.pk, "email": user.email}, salt=SALT)


def read_token(token):
    """Devolve (uid, email) ou None se inválido/expirado."""
    try:
        data = signing.loads(token, salt=SALT, max_age=MAX_AGE)
        return data["uid"], data["email"]
    except (signing.BadSignature, KeyError, TypeError):
        return None
