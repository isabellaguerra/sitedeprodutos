from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone

UF_CHOICES = [(u, u) for u in (
    "AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO".split()
)]


class UserManager(BaseUserManager):
    use_in_migrations = True

    def get_by_natural_key(self, email):
        # Login sem diferenciar maiúsculas/minúsculas
        return self.get(**{f"{self.model.USERNAME_FIELD}__iexact": email})

    def _create_user(self, email, password, **extra):
        if not email:
            raise ValueError("O e-mail é obrigatório.")
        user = self.model(email=self.normalize_email(email).lower(), **extra)
        user.set_password(password)  # hash PBKDF2 nativo do Django
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra):
        extra.setdefault("is_staff", False)
        extra.setdefault("is_superuser", False)
        return self._create_user(email, password, **extra)

    def create_superuser(self, email, password=None, **extra):
        extra.setdefault("is_staff", True)
        extra.setdefault("is_superuser", True)
        extra.setdefault("email_verified", True)
        return self._create_user(email, password, **extra)


class User(AbstractBaseUser, PermissionsMixin):
    """Usuário que entra com e-mail e senha. Níveis: cliente, equipe (is_staff) e superusuário."""

    email = models.EmailField("e-mail", unique=True)
    full_name = models.CharField("nome completo", max_length=150)
    phone = models.CharField("telefone", max_length=15, blank=True)

    # Endereço de entrega
    cep = models.CharField("CEP", max_length=8, blank=True)
    street = models.CharField("rua", max_length=150, blank=True)
    number = models.CharField("número", max_length=15, blank=True)
    complement = models.CharField("complemento", max_length=80, blank=True)
    district = models.CharField("bairro", max_length=80, blank=True)
    city = models.CharField("cidade", max_length=80, blank=True)
    state = models.CharField("UF", max_length=2, choices=UF_CHOICES, blank=True)

    email_verified = models.BooleanField("e-mail confirmado", default=False)
    is_active = models.BooleanField("ativo", default=True)
    is_staff = models.BooleanField("equipe (acessa o painel)", default=False)
    date_joined = models.DateTimeField("cadastro em", default=timezone.now)

    objects = UserManager()
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["full_name"]

    class Meta:
        verbose_name = "usuário"
        verbose_name_plural = "usuários"
        ordering = ["-date_joined"]

    def __str__(self):
        return self.email

    def get_full_name(self):
        return self.full_name

    def get_short_name(self):
        return self.full_name.split(" ")[0] if self.full_name else self.email

    @property
    def has_address(self):
        return all([self.cep, self.street, self.number, self.district, self.city, self.state])

    @property
    def address_line(self):
        if not self.has_address:
            return ""
        comp = f" - {self.complement}" if self.complement else ""
        return (f"{self.street}, {self.number}{comp} — {self.district}, "
                f"{self.city}/{self.state} — CEP {self.cep[:5]}-{self.cep[5:]}")
