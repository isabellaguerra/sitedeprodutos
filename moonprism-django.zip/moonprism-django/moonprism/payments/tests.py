import hashlib
import hmac
from decimal import Decimal
from unittest.mock import patch

from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from orders.models import Order
from shop.models import Coupon, Product
from shop.testing import make_catalog, make_coupon, make_order, make_user

from .models import Payment, WebhookEvent

SECRET = "segredo-do-webhook"
CFG = {"MERCADOPAGO_WEBHOOK_SECRET": SECRET, "MERCADOPAGO_ACCESS_TOKEN": "TEST-token", "SITE_URL": "https://loja.test"}


def sign(data_id, request_id="req-1", ts="1700000000000", secret=SECRET):
    manifest = f"id:{data_id};request-id:{request_id};ts:{ts};"
    return f"ts={ts},v1={hmac.new(secret.encode(), manifest.encode(), hashlib.sha256).hexdigest()}"


def info(order, status="approved", pid=1001, amount=None, **extra):
    return {"id": pid, "status": status, "status_detail": "accredited", "external_reference": str(order.public_id),
            "transaction_amount": float(amount if amount is not None else order.total), "currency_id": "BRL",
            "payment_method_id": "pix", "installments": 1, **extra}


@override_settings(**CFG)
class WebhookTests(TestCase):
    def setUp(self):
        cache.clear()
        self.a, _, _ = make_catalog()
        self.user = make_user("ana@example.com")
        make_coupon("SAILOR", 10)
        self.order = make_order(self.user, self.a, qty=2, coupon="SAILOR")

    def hit(self, pid=1001, signature="valid", request_id="req-1", query=None, fetch=None):
        sig = sign(pid, request_id) if signature == "valid" else signature
        url = query or f"/pagamentos/webhook/?data.id={pid}&type=payment"
        headers = {"HTTP_X_REQUEST_ID": request_id}
        if sig:
            headers["HTTP_X_SIGNATURE"] = sig
        with patch("payments.services.fetch_payment", return_value=fetch) as f:
            r = self.client.post(url, **headers)
        return r, f

    def test_valid_approved_payment_marks_order_paid(self):
        r, f = self.hit(fetch=info(self.order))
        self.assertEqual(r.status_code, 200)
        f.assert_called_once_with("1001")
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.PAID)
        self.assertIsNotNone(self.order.paid_at)
        p = Payment.objects.get()
        self.assertEqual((p.status, p.method, p.amount), (Payment.Status.APPROVED, "pix", self.order.total))
        self.assertEqual(Product.objects.get(pk=self.a.pk).stock, 3)  # 5 - 2
        self.assertEqual(Coupon.objects.get(code="SAILOR").times_used, 1)
        self.assertEqual(len(mail.outbox), 1)
        self.assertTrue(WebhookEvent.objects.get().processed)

    def test_invalid_signature_rejected_and_nothing_changes(self):
        for sig in ("valid-but-wrong", sign(1001, secret="outro-segredo"), "ts=1,v1=abc", "lixo", ""):
            r, f = self.hit(signature=sig or None, fetch=info(self.order))
            self.assertEqual(r.status_code, 403, sig)
            f.assert_not_called()
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.PENDING)
        self.assertFalse(Payment.objects.exists())

    def test_signature_bound_to_data_id(self):
        # assinatura válida para o pagamento 1001 não serve para o 2002
        r, f = self.hit(pid=2002, signature=sign(1001), fetch=info(self.order))
        self.assertEqual(r.status_code, 403)

    def test_missing_secret_refuses_everything(self):
        with override_settings(MERCADOPAGO_WEBHOOK_SECRET=""):
            r, f = self.hit(fetch=info(self.order))
        self.assertEqual(r.status_code, 503); f.assert_not_called()

    def test_get_not_allowed_and_no_csrf_needed_for_post(self):
        self.assertEqual(self.client.get("/pagamentos/webhook/").status_code, 405)
        from django.test import Client
        c = Client(enforce_csrf_checks=True)
        with patch("payments.services.fetch_payment", return_value=info(self.order)):
            r = c.post("/pagamentos/webhook/?data.id=1001&type=payment", HTTP_X_SIGNATURE=sign(1001), HTTP_X_REQUEST_ID="req-1")
        self.assertEqual(r.status_code, 200)

    def test_replay_is_idempotent(self):
        for _ in range(3):
            self.hit(fetch=info(self.order))
        self.assertEqual(Payment.objects.count(), 1)
        self.assertEqual(Product.objects.get(pk=self.a.pk).stock, 3)
        self.assertEqual(Coupon.objects.get(code="SAILOR").times_used, 1)
        self.assertEqual(len(mail.outbox), 1)

    def test_amount_mismatch_never_releases_order(self):
        r, _ = self.hit(fetch=info(self.order, amount=Decimal("1.00")))
        self.assertEqual(r.status_code, 200)
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.PENDING)
        self.assertIn("divergente", Payment.objects.get().note)
        self.assertEqual(len(mail.outbox), 0)

    def test_rejected_payment_marks_failed_then_later_approval_pays(self):
        self.hit(pid=1, signature=sign(1), fetch=info(self.order, "rejected", pid=1, status_detail="cc_rejected_other_reason"))
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.FAILED)
        self.hit(pid=2, signature=sign(2), fetch=info(self.order, "approved", pid=2))
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.PAID)
        self.assertEqual(Payment.objects.count(), 2)

    def test_late_rejection_does_not_unpay_order(self):
        self.hit(pid=1, signature=sign(1), fetch=info(self.order, "approved", pid=1))
        self.hit(pid=2, signature=sign(2), fetch=info(self.order, "rejected", pid=2))
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.PAID)

    def test_pending_and_in_process_stay_pending(self):
        for i, st in enumerate(("pending", "in_process"), start=10):
            self.hit(pid=i, signature=sign(i), fetch=info(self.order, st, pid=i))
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.PENDING)
        self.assertEqual(set(Payment.objects.values_list("status", flat=True)), {"pending", "in_process"})

    def test_refund_after_paid(self):
        self.hit(fetch=info(self.order))
        self.hit(fetch=info(self.order, "refunded"))
        self.order.refresh_from_db()
        self.assertEqual(self.order.status, Order.Status.REFUNDED)

    def test_unknown_or_forged_external_reference_is_ignored(self):
        fake = info(self.order); fake["external_reference"] = "nao-e-uuid"
        r, _ = self.hit(fetch=fake)
        self.assertEqual(r.status_code, 200)
        fake["external_reference"] = "00000000-0000-0000-0000-000000000000"
        self.hit(pid=1002, signature=sign(1002), fetch=fake)
        self.assertFalse(Payment.objects.exists())
        self.order.refresh_from_db(); self.assertEqual(self.order.status, Order.Status.PENDING)

    def test_non_payment_topics_and_bad_ids_ignored(self):
        r, f = self.hit(query="/pagamentos/webhook/?data.id=1001&type=merchant_order", fetch=None)
        self.assertEqual(r.status_code, 200); f.assert_not_called()
        r, f = self.hit(pid="abc", signature=sign("abc"), query="/pagamentos/webhook/?data.id=abc&type=payment")
        self.assertEqual(r.status_code, 200); f.assert_not_called()

    def test_gateway_outage_returns_500_so_mp_retries(self):
        from .services import GatewayError
        with patch("payments.services.fetch_payment", side_effect=GatewayError("x")):
            r = self.client.post("/pagamentos/webhook/?data.id=1001&type=payment", HTTP_X_SIGNATURE=sign(1001), HTTP_X_REQUEST_ID="req-1")
        self.assertEqual(r.status_code, 500)
        self.order.refresh_from_db(); self.assertEqual(self.order.status, Order.Status.PENDING)


@override_settings(**CFG)
class ReturnPageTests(TestCase):
    def setUp(self):
        cache.clear()
        a, _, _ = make_catalog()
        self.user = make_user("ana@example.com")
        self.order = make_order(self.user, a)
        self.client.force_login(self.user)

    def test_url_status_param_is_not_trusted(self):
        r = self.client.get(reverse("orders:confirmation", args=[self.order.public_id]) + "?status=approved&collection_status=approved")
        self.assertContains(r, "Aguardando confirmação")
        self.order.refresh_from_db(); self.assertEqual(self.order.status, Order.Status.PENDING)

    def test_return_page_verifies_with_gateway(self):
        with patch("payments.services.fetch_payment", return_value=info(self.order)) as f:
            r = self.client.get(reverse("orders:confirmation", args=[self.order.public_id]) + "?payment_id=1001")
        f.assert_called_once_with("1001")
        self.assertContains(r, "Pagamento aprovado")

    def test_return_page_failed(self):
        with patch("payments.services.fetch_payment", return_value=info(self.order, "rejected")):
            r = self.client.get(reverse("orders:confirmation", args=[self.order.public_id]) + "?payment_id=1001")
        self.assertContains(r, "Pagamento recusado")

    def test_real_gateway_response_shape_via_sdk(self):
        from unittest.mock import MagicMock
        sdk = MagicMock(); sdk.payment.return_value.get.return_value = {"status": 200, "response": info(self.order)}
        with patch("payments.services.mercadopago.SDK", return_value=sdk):
            self.client.get(reverse("orders:confirmation", args=[self.order.public_id]) + "?payment_id=1001")
        sdk.payment.return_value.get.assert_called_once_with("1001")
        self.order.refresh_from_db(); self.assertEqual(self.order.status, Order.Status.PAID)
