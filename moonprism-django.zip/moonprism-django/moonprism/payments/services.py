"""Integração com o Mercado Pago (Checkout Pro).

O cliente paga na página do Mercado Pago: dados de cartão e Pix NUNCA passam por este servidor.
O status do pedido só muda depois que consultamos o pagamento diretamente na API do gateway.
"""
import logging
from decimal import Decimal, InvalidOperation

import mercadopago
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.mail import send_mail
from django.db import transaction
from django.db.models import F
from django.urls import reverse
from django.utils import timezone

from orders.models import Order
from shop.models import Coupon, Product

from .models import Payment

log = logging.getLogger("payments")


class GatewayError(Exception):
    """Erro apresentável ao usuário (mensagem já em português)."""


STATUS_MAP = {
    "approved": Payment.Status.APPROVED,
    "authorized": Payment.Status.IN_PROCESS,
    "pending": Payment.Status.PENDING,
    "in_process": Payment.Status.IN_PROCESS,
    "in_mediation": Payment.Status.IN_PROCESS,
    "rejected": Payment.Status.REJECTED,
    "cancelled": Payment.Status.CANCELLED,
    "refunded": Payment.Status.REFUNDED,
    "charged_back": Payment.Status.REFUNDED,
}


def get_sdk():
    token = settings.MERCADOPAGO_ACCESS_TOKEN
    if not token:
        raise GatewayError("O pagamento ainda não foi configurado pela loja. Tente novamente mais tarde.")
    return mercadopago.SDK(token)


def create_checkout(order):
    """Cria a preferência de pagamento e devolve a URL do checkout hospedado."""
    sdk = get_sdk()
    base = settings.SITE_URL
    back = base + reverse("orders:confirmation", args=[order.public_id])
    data = {
        # Um único item com o valor final (produtos - cupom + frete) calculado no servidor
        "items": [{
            "id": str(order.public_id),
            "title": f"Moon Prism Shop — pedido {order.code}",
            "quantity": 1,
            "currency_id": "BRL",
            "unit_price": float(order.total),
        }],
        "payer": {"email": order.user.email, "name": order.user.full_name},
        "external_reference": str(order.public_id),
        "back_urls": {"success": back, "pending": back, "failure": back},
        "statement_descriptor": "MOONPRISM",
        "payment_methods": {
            "excluded_payment_types": [{"id": "ticket"}, {"id": "atm"}],  # sem boleto/lotérica: Pix e cartão
            "installments": settings.MAX_INSTALLMENTS,
        },
    }
    if base.startswith("https://"):
        # O Mercado Pago só aceita retorno automático e webhook em URLs públicas HTTPS
        data["auto_return"] = "approved"
        data["notification_url"] = base + reverse("payments:webhook")
    try:
        result = sdk.preference().create(data)
    except Exception:
        log.exception("Falha de rede ao criar preferência do pedido %s", order.code)
        raise GatewayError("Não conseguimos falar com o Mercado Pago agora. Tente de novo em instantes.")
    if result.get("status") not in (200, 201) or "init_point" not in result.get("response", {}):
        log.error("Preferência recusada (%s): %s", order.code, result.get("response"))
        raise GatewayError("O Mercado Pago não aceitou o pedido. Tente de novo ou fale com a loja.")
    return result["response"]["init_point"]


def fetch_payment(payment_id):
    sdk = get_sdk()
    try:
        result = sdk.payment().get(payment_id)
    except Exception:
        log.exception("Falha ao consultar pagamento %s", payment_id)
        raise GatewayError("Não conseguimos consultar o pagamento agora.")
    if result.get("status") != 200:
        raise GatewayError("Pagamento não encontrado no gateway.")
    return result["response"]


def sync_payment(payment_id):
    """Consulta o pagamento no gateway (fonte da verdade) e atualiza Payment e Order. Idempotente."""
    info = fetch_payment(payment_id)
    return apply_payment_info(info)


@transaction.atomic
def apply_payment_info(info):
    ref = str(info.get("external_reference") or "")
    try:
        order = Order.objects.select_for_update().get(public_id=ref)
    except (Order.DoesNotExist, ValidationError, ValueError) as exc:  # referência desconhecida/forjada
        log.warning("Pagamento %s sem pedido válido (ref=%r): %s", info.get("id"), ref, exc)
        return None

    status = STATUS_MAP.get(info.get("status"), Payment.Status.PENDING)
    try:
        amount = Decimal(str(info.get("transaction_amount")))
    except (InvalidOperation, TypeError):
        amount = Decimal("0")

    note = ""
    if status == Payment.Status.APPROVED:
        if amount != order.total or info.get("currency_id") not in (None, "BRL"):
            note = f"Valor divergente: pago {amount}, esperado {order.total}"
            log.error("%s — pedido %s", note, order.code)

    payment, _ = Payment.objects.update_or_create(
        gateway_payment_id=str(info["id"]),
        defaults={
            "order": order, "status": status,
            "status_detail": str(info.get("status_detail") or "")[:80],
            "method": str(info.get("payment_method_id") or info.get("payment_type_id") or "")[:30],
            "installments": int(info.get("installments") or 1),
            "amount": amount, "note": note,
        },
    )

    if note:
        return payment  # nunca libera pedido com valor divergente: revisão manual no painel
    _update_order(order, payment)
    return payment


def _update_order(order, payment):
    if payment.status == Payment.Status.APPROVED:
        if order.status != Order.Status.PAID:
            order.status = Order.Status.PAID
            order.paid_at = timezone.now()
            order.save(update_fields=["status", "paid_at"])
            _after_paid(order)
    elif payment.status == Payment.Status.REFUNDED:
        if order.status == Order.Status.PAID:
            order.status = Order.Status.REFUNDED
            order.save(update_fields=["status"])
    elif payment.status in (Payment.Status.REJECTED, Payment.Status.CANCELLED):
        # Só marca como recusado se não existir outro pagamento aprovado para o pedido
        if order.status == Order.Status.PENDING and not order.payments.filter(status=Payment.Status.APPROVED).exists():
            order.status = Order.Status.FAILED
            order.save(update_fields=["status"])
    elif order.status == Order.Status.FAILED:
        # Nova tentativa em andamento (ex.: Pix gerado depois de um cartão recusado)
        order.status = Order.Status.PENDING
        order.save(update_fields=["status"])


def _after_paid(order):
    if not order.stock_applied:
        for item in order.items.all():
            if item.product_id:
                updated = Product.objects.filter(pk=item.product_id, stock__gte=item.quantity).update(
                    stock=F("stock") - item.quantity)
                if not updated:  # estoque insuficiente: zera (venda já paga, a loja repõe)
                    Product.objects.filter(pk=item.product_id).update(stock=0)
        if order.coupon_code:
            Coupon.objects.filter(code=order.coupon_code).update(times_used=F("times_used") + 1)
        Order.objects.filter(pk=order.pk).update(stock_applied=True)
    try:
        lines = "\n".join(f"  • {i.quantity}× {i.name}" for i in order.items.all())
        send_mail(
            f"Pagamento confirmado — pedido {order.code} 🌙",
            f"Oi, {order.user.get_short_name()}!\n\nRecebemos o pagamento do pedido {order.code}.\n\n{lines}\n\n"
            f"Total: R$ {order.total}\nEntrega em: {order.ship_address}\n\n"
            f"Acompanhe em {settings.SITE_URL}{reverse('orders:detail', args=[order.public_id])}\n\nCom amor, Moon Prism Shop ✨",
            settings.DEFAULT_FROM_EMAIL, [order.user.email], fail_silently=True,
        )
    except Exception:  # e-mail nunca pode derrubar a confirmação do pagamento
        log.exception("Falha ao enviar e-mail do pedido %s", order.code)
