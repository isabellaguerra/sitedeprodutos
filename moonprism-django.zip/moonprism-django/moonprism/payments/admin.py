from django.contrib import admin

from .models import Payment, WebhookEvent


class ReadOnlyAdmin(admin.ModelAdmin):
    """Transações financeiras são registro de auditoria: só consulta."""

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Payment)
class PaymentAdmin(ReadOnlyAdmin):
    list_display = ("gateway_payment_id", "order", "status", "method", "installments", "amount", "note", "created_at")
    list_filter = ("status", "method", "created_at")
    search_fields = ("gateway_payment_id", "order__user__email", "order__ship_name")
    date_hierarchy = "created_at"


@admin.register(WebhookEvent)
class WebhookEventAdmin(ReadOnlyAdmin):
    list_display = ("received_at", "topic", "resource_id", "signature_valid", "processed", "detail")
    list_filter = ("signature_valid", "processed", "topic")
