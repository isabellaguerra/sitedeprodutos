import hashlib
import hmac
import logging
import re

from django.conf import settings
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from . import services
from .models import WebhookEvent

log = logging.getLogger("payments")


def valid_signature(request, data_id):
    """Valida o cabeçalho x-signature do Mercado Pago (HMAC-SHA256 do 'manifest')."""
    secret = settings.MERCADOPAGO_WEBHOOK_SECRET
    header = request.headers.get("x-signature", "")
    request_id = request.headers.get("x-request-id", "")
    if not secret or not header:
        return False
    parts = dict(p.strip().split("=", 1) for p in header.split(",") if "=" in p)
    ts, v1 = parts.get("ts"), parts.get("v1")
    if not ts or not v1:
        return False
    manifest = ""
    if data_id:
        manifest += f"id:{data_id.lower() if data_id.isalnum() else data_id};"
    if request_id:
        manifest += f"request-id:{request_id};"
    manifest += f"ts:{ts};"
    expected = hmac.new(secret.encode(), manifest.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, v1)


@csrf_exempt  # chamada servidor-a-servidor: autenticada pela assinatura, não por cookie/CSRF
@require_POST
def webhook(request):
    data_id = request.GET.get("data.id", "")[:60]
    topic = (request.GET.get("type") or request.GET.get("topic") or "")[:40]
    event = WebhookEvent.objects.create(topic=topic, resource_id=data_id)

    if not settings.MERCADOPAGO_WEBHOOK_SECRET:
        event.detail = "MERCADOPAGO_WEBHOOK_SECRET não configurado"
        event.save(update_fields=["detail"])
        log.error(event.detail)
        return HttpResponse(status=503)

    if not valid_signature(request, data_id):
        event.detail = "assinatura inválida"
        event.save(update_fields=["detail"])
        log.warning("Webhook com assinatura inválida (id=%s)", data_id)
        return HttpResponse(status=403)

    event.signature_valid = True
    if topic != "payment" or not re.fullmatch(r"\d{1,20}", data_id):
        event.detail = "evento ignorado"
        event.save(update_fields=["signature_valid", "detail"])
        return HttpResponse(status=200)

    try:
        payment = services.sync_payment(data_id)
        event.processed = payment is not None
        event.detail = "ok" if payment else "pedido não encontrado"
        event.save(update_fields=["signature_valid", "processed", "detail"])
        return HttpResponse(status=200)
    except services.GatewayError as exc:
        event.detail = str(exc)[:200]
        event.save(update_fields=["signature_valid", "detail"])
        return HttpResponse(status=500)  # o Mercado Pago tenta de novo
