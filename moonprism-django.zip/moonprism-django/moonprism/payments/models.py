from django.db import models

from orders.models import Order


class Payment(models.Model):
    """Espelho de um pagamento no gateway. Nunca guarda número de cartão, CVV ou dados sensíveis."""

    class Status(models.TextChoices):
        PENDING = "pending", "Pendente"
        IN_PROCESS = "in_process", "Em análise"
        APPROVED = "approved", "Aprovado"
        REJECTED = "rejected", "Recusado"
        CANCELLED = "cancelled", "Cancelado"
        REFUNDED = "refunded", "Reembolsado"

    order = models.ForeignKey(Order, on_delete=models.PROTECT, related_name="payments", verbose_name="pedido")
    gateway = models.CharField(max_length=20, default="mercadopago")
    gateway_payment_id = models.CharField("ID no gateway", max_length=40, unique=True)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING, db_index=True)
    status_detail = models.CharField("detalhe", max_length=80, blank=True)
    method = models.CharField("forma de pagamento", max_length=30, blank=True)
    installments = models.PositiveSmallIntegerField("parcelas", default=1)
    amount = models.DecimalField("valor", max_digits=9, decimal_places=2)
    note = models.CharField("observação", max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "pagamento"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.gateway_payment_id} — {self.get_status_display()}"

    @property
    def method_label(self):
        return {
            "pix": "Pix", "credit_card": "Cartão de crédito", "debit_card": "Cartão de débito",
            "account_money": "Saldo Mercado Pago", "bank_transfer": "Transferência", "master": "Cartão de crédito",
            "visa": "Cartão de crédito",
        }.get(self.method, self.method or "—")


class WebhookEvent(models.Model):
    """Registro de cada notificação recebida (auditoria e diagnóstico)."""

    received_at = models.DateTimeField(auto_now_add=True)
    topic = models.CharField(max_length=40, blank=True)
    resource_id = models.CharField(max_length=60, blank=True)
    signature_valid = models.BooleanField(default=False)
    processed = models.BooleanField(default=False)
    detail = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name = "notificação do gateway"
        verbose_name_plural = "notificações do gateway"
        ordering = ["-received_at"]

    def __str__(self):
        return f"{self.topic} {self.resource_id}"
